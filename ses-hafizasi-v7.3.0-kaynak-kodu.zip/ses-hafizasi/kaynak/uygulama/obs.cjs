async function hashBase64(value) {
  const bytes = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value));
  return btoa(String.fromCharCode(...new Uint8Array(bytes)));
}
class ObsClient {
  constructor() { this.socket = null; this.pending = new Map(); this.sequence = 0; this.ready = false; this.onEvent = () => {}; this.onClose = () => {}; }
  async connect(port, password) {
    this.close();
    port = Number(port);
    if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('OBS portu 1–65535 arasında olmalı. Varsayılan 4455.');
    const socket = new WebSocket(`ws://127.0.0.1:${port}`);
    this.socket = socket;
    await new Promise((resolve, reject) => {
      const timer = setTimeout(() => { this.close(); reject(new Error('OBS bağlantısı kurulamadı. OBS → Araçlar → WebSocket Sunucu Ayarları bölümünde sunucuyu aç.')); }, 5000);
      const fail = error => { clearTimeout(timer); reject(error); };
      socket.onerror = () => fail(new Error('OBS’ye erişilemiyor. OBS açık mı ve WebSocket sunucusu etkin mi?'));
      socket.onclose = event => {
        this.ready = false;
        fail(new Error(event.code === 4009 ? 'OBS parolası yanlış.' : 'OBS bağlantısı kapandı.'));
        this.rejectPending(); this.onClose();
      };
      socket.onmessage = async event => {
        try {
          const message = JSON.parse(event.data);
          if (message.op === 0) {
            const data = { rpcVersion: 1, eventSubscriptions: 65536 | 4 | 8 };
            if (message.d.authentication) {
              const { salt, challenge } = message.d.authentication;
              data.authentication = await hashBase64((await hashBase64(password + salt)) + challenge);
            }
            socket.send(JSON.stringify({ op: 1, d: data }));
          } else if (message.op === 2) { clearTimeout(timer); this.ready = true; resolve(); }
          else if (message.op === 5) this.onEvent(message.d);
          else if (message.op === 7) {
            const pending = this.pending.get(message.d.requestId);
            if (!pending) return;
            clearTimeout(pending.timer); this.pending.delete(message.d.requestId);
            if (message.d.requestStatus.result) pending.resolve(message.d.responseData || {});
            else pending.reject(new Error(`${message.d.requestType}: ${message.d.requestStatus.comment || message.d.requestStatus.code}`));
          }
        } catch (error) { fail(error); }
      };
    });
  }
  request(requestType, requestData = {}) {
    if (!this.ready) return Promise.reject(new Error('Önce OBS’ye bağlan.'));
    const requestId = String(++this.sequence);
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => { this.pending.delete(requestId); reject(new Error(`OBS yanıt vermedi: ${requestType}`)); }, 4000);
      this.pending.set(requestId, { resolve, reject, timer });
      this.socket.send(JSON.stringify({ op: 6, d: { requestType, requestId, requestData } }));
    });
  }
  rejectPending() { for (const item of this.pending.values()) { clearTimeout(item.timer); item.reject(new Error('OBS bağlantısı kesildi.')); } this.pending.clear(); }
  close() { if (this.socket) { this.socket.onclose = null; this.socket.close(); } this.socket = null; this.ready = false; this.rejectPending(); }
}

function isOurReceiver(value, address) {
  try {
    const url = new URL(value), own = new URL(address);
    return url.origin === own.origin && url.pathname === '/' && url.searchParams.get('key') === own.searchParams.get('key');
  } catch { return false; }
}
async function planObs(client, address) {
  const session = new URL(address).searchParams.get('key').slice(0, 8);
  const inputName = `Ses Hafızası Yayın ${session}`;
  const sceneName = `Ses Hafızası Test ${session}`;
  const [inputs, special, scenes, kinds] = await Promise.all([
    client.request('GetInputList'), client.request('GetSpecialInputs'), client.request('GetSceneList'), client.request('GetInputKindList', { unversioned: true })
  ]);
  if (!kinds.inputKinds.includes('browser_source')) throw new Error('OBS Tarayıcı kaynağı desteklemiyor. Tarayıcı bileşenli OBS Studio gerekiyor.');
  const existing = inputs.inputs.find(input => input.inputName === inputName);
  if (existing && existing.inputKind !== 'browser_source') throw new Error('Aynı isimde farklı türde kaynak var. Kaynağın adını değiştir.');
  const conflicts = [];
  for (const input of inputs.inputs) {
    if (input.inputName === inputName) continue;
    let conflict = [special.desktop1, special.desktop2].filter(Boolean).includes(input.inputName);
    if (input.inputKind === 'wasapi_process_output_capture' || input.inputKind === 'browser_source') {
      const { inputSettings } = await client.request('GetInputSettings', { inputName: input.inputName });
      if (input.inputKind === 'browser_source') conflict ||= isOurReceiver(inputSettings.url, address);
      else conflict ||= /(^|:)brave\.exe($|:)/i.test(inputSettings.window || '');
    }
    if (conflict) {
      const state = await client.request('GetInputMute', { inputName: input.inputName });
      if (!state.inputMuted) conflicts.push(input.inputName);
    }
  }
  if (existing) {
    const { inputSettings } = await client.request('GetInputSettings', { inputName });
    if (!isOurReceiver(inputSettings.url, address)) throw new Error('Aynı isimdeki kaynak bu uygulamaya ait değil; adı değiştirilmeden kullanılmayacak.');
  }
  return { inputName, sceneName, conflicts, existing: !!existing, sceneExists: scenes.scenes.some(scene => scene.sceneName === sceneName) };
}
async function configureObs(client, address, plan, persistBackup) {
  const url = new URL(address); url.searchParams.set('view', 'obs');
  const inputSettings = { url: url.href, width: 500, height: 160, reroute_audio: true, shutdown: false, restart_when_active: false, webpage_control_level: 1, css: 'body { margin: 0; background: transparent; }' };
  if (!plan.sceneExists) await client.request('CreateScene', { sceneName: plan.sceneName });
  if (!plan.existing) {
    await client.request('CreateInput', { sceneName: plan.sceneName, inputName: plan.inputName, inputKind: 'browser_source', inputSettings, sceneItemEnabled: true });
  } else {
    const current = await client.request('GetInputSettings', { inputName: plan.inputName });
    // Aynı sekme/başlat işlemi OBS tarayıcı kaynağını tekrar yüklememeli.
    if (Object.entries(inputSettings).some(([key, value]) => current.inputSettings[key] !== value)) {
      await client.request('SetInputSettings', { inputName: plan.inputName, inputSettings, overlay: true });
    }
    const { sceneItems } = await client.request('GetSceneItemList', { sceneName: plan.sceneName });
    const item = sceneItems.find(item => item.sourceName === plan.inputName);
    if (!item) await client.request('CreateSceneItem', { sceneName: plan.sceneName, sourceName: plan.inputName, sceneItemEnabled: true });
    else await client.request('SetSceneItemEnabled', { sceneName: plan.sceneName, sceneItemId: item.sceneItemId, sceneItemEnabled: true });
  }
  await client.request('SetInputAudioMonitorType', { inputName: plan.inputName, monitorType: 'OBS_MONITORING_TYPE_NONE' });
  await client.request('SetInputVolume', { inputName: plan.inputName, inputVolumeMul: 1 });
  await client.request('SetInputMute', { inputName: plan.inputName, inputMuted: false });
  const changed = [];
  try {
    for (const inputName of plan.conflicts) {
      const { inputMuted } = await client.request('GetInputMute', { inputName });
      if (inputMuted) continue;
      // Değiştirmeden önce kalıcı geri alma kaydı oluştur.
      changed.push({ inputName, inputMuted });
      await persistBackup(changed);
      await client.request('SetInputMute', { inputName, inputMuted: true });
    }
  } catch (error) {
    for (const previous of changed) await client.request('SetInputMute', previous).catch(() => {});
    throw error;
  }
  const [settings, monitor, mute, volume] = await Promise.all([
    client.request('GetInputSettings', { inputName: plan.inputName }), client.request('GetInputAudioMonitorType', { inputName: plan.inputName }),
    client.request('GetInputMute', { inputName: plan.inputName }), client.request('GetInputVolume', { inputName: plan.inputName })
  ]);
  if (!settings.inputSettings.reroute_audio || monitor.monitorType !== 'OBS_MONITORING_TYPE_NONE' || mute.inputMuted || Math.abs(volume.inputVolumeMul - 1) > .001) throw new Error('OBS kaynak ayarları doğrulanamadı.');
  return changed;
}

module.exports = { ObsClient, planObs, configureObs };
