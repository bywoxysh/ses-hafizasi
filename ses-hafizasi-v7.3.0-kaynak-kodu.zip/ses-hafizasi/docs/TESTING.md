# Verification

The reviewed 7.2.1 audio code passed real Chromium tab capture and AudioWorklet output through the packaged Linux SEA helper. OBS requests were handled by a protocol simulator. The maintainer separately reported a successful real Windows Brave/OBS broadcast with 7.2.0. 7.3.0 changes only the visible extension name/metadata.

Covered: independent headphone/broadcast levels, a second audible tab excluded, 0.1 dB steps, mute/unmute, saved-setting migration, three selected-tab close/reopen cycles, four real OBS WebSocket disconnect/reconnect cycles without duplicate sources, and undo of conflicting-source mutes.

OfflineAudioContext verification covers the initial gain from the first sample and zero output at muted startup. Unit/relay checks cover live connection reuse, disabled-server setup, reconfiguration, key/origin validation, second publisher rejection, fragmented PCM, ping and malformed sample rejection.

`npm test` runs the unit and local relay checks. `npm run test:audio` runs the real browser's offline gain checks. `npm run test:browser` runs source Node.js plus a real Chromium extension and OBS simulator. Ports 8765, 8877 and 14455 must be available; no real OBS installation is modified by the simulator fixture.

Recorded results are in `testler/*.json`. A test run may replace them. The simulator cannot verify the real Windows OBS CEF/output-device pipeline.
