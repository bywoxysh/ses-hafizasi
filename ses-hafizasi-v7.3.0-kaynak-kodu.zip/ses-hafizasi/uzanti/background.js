async function restoreSource(tabId) {
  try {
    await chrome.scripting.executeScript({ target: { tabId }, func: () => window.__sesHafizasi6?.stop() });
  } catch { /* Sekme kapatılmış veya başka bir adrese gitmiş olabilir. */ }
}
chrome.action.onClicked.addListener(async tab => {
  if (!tab.id || !/^https?:/.test(tab.url || '')) {
    await chrome.tabs.create({ url: chrome.runtime.getURL('help.html') });
    return;
  }
  const url = chrome.runtime.getURL(`control.html?source=${tab.id}`);
  const panels = await chrome.tabs.query({ url: chrome.runtime.getURL('control.html*') });
  const existing = panels.find(panel => panel.url === url);
  if (existing) {
    await chrome.tabs.update(existing.id, { active: true });
    await chrome.windows.update(existing.windowId, { focused: true });
    return;
  }
  const panel = await chrome.windows.create({ url, type: 'popup', width: 460, height: 760 });
  const { controllers = {} } = await chrome.storage.session.get('controllers');
  controllers[panel.tabs[0].id] = tab.id;
  await chrome.storage.session.set({ controllers });
});
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (!['capture', 'restore-source'].includes(message.type) || sender.id !== chrome.runtime.id ||
      !sender.url?.startsWith(chrome.runtime.getURL('control.html?'))) return;
  const source = Number(new URL(sender.url).searchParams.get('source'));
  if (!Number.isInteger(source) || source <= 0) { reply({ error: 'Kaynak sekme bulunamadı.' }); return; }
  (async () => {
    if (message.type === 'restore-source') { await restoreSource(source); return { ok: true }; }
    const consumer = await chrome.tabs.get(message.consumerTabId);
    if (consumer.url !== sender.url) throw new Error('Kontrol penceresi doğrulanamadı.');
    return { streamId: await chrome.tabCapture.getMediaStreamId({ targetTabId: source, consumerTabId: consumer.id }) };
  })().then(reply).catch(error => reply({ error: error.message }));
  return true;
});
chrome.tabs.onRemoved.addListener(async removedId => {
  const { controllers = {} } = await chrome.storage.session.get('controllers');
  if (!controllers[removedId]) return;
  const source = controllers[removedId];
  delete controllers[removedId];
  await chrome.storage.session.set({ controllers });
  await restoreSource(source);
});
