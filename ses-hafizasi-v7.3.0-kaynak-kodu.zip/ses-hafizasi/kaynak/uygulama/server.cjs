// Yalnızca Node.js standart kütüphanesi. npm paketi veya ses sürücüsü yok.
const http = require('node:http');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const MAX_FRAME = 65536;

function frame(payload, opcode = 2) {
  payload = Buffer.from(payload);
  const header = Buffer.alloc(payload.length < 126 ? 2 : 4);
  header[0] = 0x80 | opcode;
  if (payload.length < 126) header[1] = payload.length;
  else { header[1] = 126; header.writeUInt16BE(payload.length, 2); }
  return Buffer.concat([header, payload]);
}

class Peer {
  constructor(socket, onMessage, onClose) {
    this.socket = socket;
    this.pending = Buffer.alloc(0);
    this.parts = [];
    this.partBytes = 0;
    this.partOpcode = 0;
    this.closed = false;
    this.onMessage = onMessage;
    this.onClose = onClose;
    socket.on('data', chunk => this.feed(chunk));
    socket.on('error', () => this.close());
    socket.on('close', () => this.close());
  }
  send(payload, opcode = 2) {
    if (this.closed) return;
    if (this.socket.writableLength > MAX_FRAME * 2) { this.close(); return; }
    this.socket.write(frame(payload, opcode));
  }
  close() {
    if (this.closed) return;
    this.closed = true;
    this.socket.destroy();
    this.pending = Buffer.alloc(0);
    this.parts = [];
    this.onClose(this);
  }
  feed(chunk) {
    if (this.closed) return;
    this.pending = Buffer.concat([this.pending, chunk]);
    while (!this.closed && this.pending.length >= 2) {
      const data = this.pending;
      const final = !!(data[0] & 0x80), opcode = data[0] & 15;
      if ((data[0] & 0x70) || !(data[1] & 0x80)) return this.close();
      let length = data[1] & 127, offset = 2;
      if (length === 126) {
        if (data.length < 4) return;
        length = data.readUInt16BE(2); offset = 4;
      } else if (length === 127) {
        if (data.length < 10) return;
        const large = data.readBigUInt64BE(2);
        if (large > BigInt(MAX_FRAME)) return this.close();
        length = Number(large); offset = 10;
      }
      if (length > MAX_FRAME || (opcode >= 8 && (!final || length > 125))) return this.close();
      if (data.length < offset + 4 + length) return;
      const mask = data.subarray(offset, offset + 4);
      offset += 4;
      const payload = Buffer.from(data.subarray(offset, offset + length));
      for (let i = 0; i < length; i++) payload[i] ^= mask[i % 4];
      this.pending = data.subarray(offset + length);
      if (opcode === 8) { this.send(payload, 8); return this.close(); }
      if (opcode === 9) { this.send(payload, 10); continue; }
      if (opcode === 10) continue;
      if (opcode === 0) {
        if (!this.partOpcode) return this.close();
      } else if (opcode === 1 || opcode === 2) {
        if (this.partOpcode) return this.close();
        this.partOpcode = opcode;
      } else return this.close();
      this.parts.push(payload); this.partBytes += length;
      if (this.partBytes > MAX_FRAME) return this.close();
      if (final) {
        const message = Buffer.concat(this.parts, this.partBytes);
        const type = this.partOpcode;
        this.parts = []; this.partBytes = 0; this.partOpcode = 0;
        this.onMessage(message, type, this);
      }
    }
  }
}

function validPacket(data) {
  if (data.length < 8) return false;
  const rate = data.readUInt32LE(0), frames = data.readUInt32LE(4);
  if (rate < 8000 || rate > 192000 || frames < 1 || frames > 4096 || data.length !== 8 + frames * 8) return false;
  for (let offset = 8; offset < data.length; offset += 4) {
    const value = data.readFloatLE(offset);
    if (!Number.isFinite(value) || Math.abs(value) > 16) return false;
  }
  return true;
}

function createRelay({ key, port = 8765, api, assetReader } = {}) {
  if (!/^[a-f0-9]{64}$/.test(key || '')) throw new Error('Geçersiz bağlantı anahtarı.');
  const listeners = new Set();
  const peers = new Set();
  let publisher = null;
  let actualPort = port;
  let heartbeat;
  const assets = {
    '/': ['receiver.html', 'text/html; charset=utf-8'],
    '/receiver.js': ['receiver.js', 'text/javascript; charset=utf-8'],
    '/playback-worklet.js': ['playback-worklet.js', 'text/javascript; charset=utf-8']
  };
  assets['/app'] = ['app.html', 'text/html; charset=utf-8'];
  assets['/app.js'] = ['app.js', 'text/javascript; charset=utf-8'];
  const validHost = req => req.headers.host === `127.0.0.1:${actualPort}`;
  const authorized = url => {
    const candidate = url.searchParams.get('key') || '';
    return /^[a-f0-9]{64}$/.test(candidate) && crypto.timingSafeEqual(Buffer.from(candidate), Buffer.from(key));
  };
  function notify() {
    const ready = [...listeners].filter(peer => peer.receiverState?.audioState === 'running' && Date.now() - peer.receiverState.lastAdvance < 1800).length;
    publisher?.send(JSON.stringify({ type: 'receivers', count: listeners.size, ready }), 1);
  }
  function receiverState() {
    for (const peer of listeners) peer.send(JSON.stringify({ type: 'publisher', active: !!publisher }), 1);
  }
  const server = http.createServer((req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'no-referrer');
    res.setHeader('Content-Security-Policy', `default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self' ws://127.0.0.1:${actualPort}; frame-ancestors 'none'`);
    const url = new URL(req.url, 'http://127.0.0.1');
    if (url.pathname.startsWith('/api/')) {
      const origin = req.headers.origin || '';
      const allowed = !origin || origin === `http://127.0.0.1:${actualPort}` || /^chrome-extension:\/\/[a-p]{32}$/.test(origin);
      if (!validHost(req) || !allowed || req.headers['x-ses-hafizasi'] !== '7' || !api) { res.writeHead(403); return res.end(); }
      api(req.method, url.pathname).then(value => { res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' }); res.end(JSON.stringify(value)); })
        .catch(error => { res.writeHead(400, { 'Content-Type': 'application/json; charset=utf-8' }); res.end(JSON.stringify({ error: error.message })); });
      return;
    }
    if (url.pathname === '/pair') {
      const origin = req.headers.origin || '';
      const extension = /^chrome-extension:\/\/[a-p]{32}$/.test(origin);
      if (!validHost(req) || (origin && !extension)) { res.writeHead(403); return res.end(); }
      if (extension) {
        res.setHeader('Access-Control-Allow-Origin', origin);
        res.setHeader('Vary', 'Origin');
      }
      if (req.method === 'OPTIONS' && extension) {
        res.writeHead(204, { 'Access-Control-Allow-Methods': 'GET', 'Access-Control-Allow-Headers': 'X-Ses-Hafizasi' });
        return res.end();
      }
      if (req.method !== 'GET' || req.headers['x-ses-hafizasi'] !== '7') { res.writeHead(403); return res.end(); }
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ address: `http://127.0.0.1:${actualPort}/?key=${key}`, version: '7.2.0' }));
    }
    if (!validHost(req) || req.method !== 'GET') { res.writeHead(403); return res.end('Erişim reddedildi.'); }
    if (!assets[url.pathname]) { res.writeHead(404); return res.end(); }
    if (url.pathname === '/' && !authorized(url)) { res.writeHead(403); return res.end('Uygulamanın verdiği tam OBS adresini kullan.'); }
    const [name, type] = assets[url.pathname];
    res.writeHead(200, { 'Content-Type': type });
    res.end(assetReader ? assetReader(name) : fs.readFileSync(path.join(__dirname, name)));
  });
  server.on('upgrade', (req, socket, head) => {
    socket.on('error', () => socket.destroy());
    const url = new URL(req.url, 'http://127.0.0.1');
    const origin = req.headers.origin || '';
    const localOrigin = origin === `http://127.0.0.1:${actualPort}`;
    const extensionOrigin = /^chrome-extension:\/\/[a-p]{32}$/.test(origin);
    const isPublisher = url.pathname === '/publish';
    const wsKey = req.headers['sec-websocket-key'] || '';
    if (req.method !== 'GET' || req.headers.upgrade?.toLowerCase() !== 'websocket' ||
        !validHost(req) || !authorized(url) || req.headers['sec-websocket-version'] !== '13' ||
        !/^[A-Za-z0-9+/]{22}==$/.test(wsKey) ||
        (isPublisher ? !extensionOrigin : url.pathname !== '/listen' || !localOrigin) ||
        (isPublisher && publisher)) {
      socket.end('HTTP/1.1 403 Forbidden\r\nConnection: close\r\nContent-Length: 0\r\n\r\n');
      return;
    }
    const accept = crypto.createHash('sha1').update(wsKey + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
    socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
    socket.setNoDelay(true);
    const peer = new Peer(socket, (data, opcode, current) => {
      if (!isPublisher) {
        try {
          if (opcode !== 1 || data.length > 1024) return current.close();
          const state = JSON.parse(data.toString('utf8'));
          if (state.type !== 'receiver-status' || state.obs !== true || state.revision !== 6 ||
              !['running', 'suspended', 'closed'].includes(state.audioState) ||
              !Number.isSafeInteger(state.played) || state.played < 0) return current.close();
          const previous = current.receiverState;
          const advancing = state.played > (previous?.played || 0);
          current.receiverState = { audioState: state.audioState, played: state.played, lastAdvance: advancing ? Date.now() : (previous?.lastAdvance || 0) };
          notify();
        } catch { current.close(); }
        return;
      }
      if (opcode !== 2 || !validPacket(data)) return current.close();
      for (const listener of listeners) listener.send(data);
    }, current => {
      peers.delete(current);
      listeners.delete(current);
      if (publisher === current) {
        publisher = null;
        receiverState();
      }
      notify();
    });
    peers.add(peer);
    if (isPublisher) publisher = peer;
    else listeners.add(peer);
    notify(); receiverState();
    if (head.length) peer.feed(head);
  });
  server.on('listening', () => {
    actualPort = server.address().port;
    heartbeat = setInterval(notify, 600);
    heartbeat.unref();
  });
  server.on('close', () => clearInterval(heartbeat));
  return {
    server,
    listen: () => new Promise((resolve, reject) => {
      server.once('error', reject);
      server.listen(port, '127.0.0.1', () => { server.removeListener('error', reject); resolve(actualPort); });
    }),
    close: () => new Promise(resolve => { for (const peer of peers) peer.close(); server.close(resolve); })
  };
}

if (require.main === module) {
  const keyFile = path.join(__dirname, '.local-key');
  let key = '';
  try { key = fs.readFileSync(keyFile, 'utf8').trim(); } catch {}
  if (!/^[a-f0-9]{64}$/.test(key)) {
    key = crypto.randomBytes(32).toString('hex');
    fs.writeFileSync(keyFile, key, { mode: 0o600 });
  }
  const relay = createRelay({ key });
  relay.listen().then(() => {
    const address = `http://127.0.0.1:8765/?key=${key}`;
    fs.writeFileSync(path.join(__dirname, 'OBS-ADRESI.txt'), address + '\r\n');
    console.log('\nSES HAFIZASI CALISIYOR (6.0)\n');
    console.log('Uzanti uygulamayi otomatik bulur. OBS kaynagini uzantidan kur.');
    console.log('1. YouTube sekmesinde Ses Hafizasi 6 uzanti simgesine tikla.');
    console.log('2. OBS WebSocket sunucusunu ac; port ve parolayi uzantiya gir.');
    console.log('3. Uzantidaki OBS kurulumu dugmesini kullan. Kaynak otomatik olusur.');
    console.log('\nBu pencere acik kalsin. Kapatmak icin Ctrl+C.');
    console.log('Gerekirse el ile kurulum adresi uygulama/OBS-ADRESI.txt dosyasinda.\n');
  }).catch(error => {
    console.error(error.code === 'EADDRINUSE' ? '8765 portu kullaniliyor. Diger Ses Hafizasi penceresini kapat.' : error.message);
    process.exitCode = 1;
  });
  process.on('SIGINT', () => relay.close().then(() => process.exit()));
}
module.exports = { createRelay, Peer, frame, validPacket };
