7.2 doğrulaması

- Gerçek Chromium sekme yakalama, AudioWorklet çıkışı ve paketlenmiş Linux SEA kullanıldı.
- OBS bağlantısı protokol simülatörüyle doğrulandı; Windows EXE gerçek OBS üzerinde çalıştırılmadı.
- Üç kez kaynak sekme kapatılıp yeni sekmeden Başlat yapıldı. Her seferinde gerçek ses alındı.
- İlk kaynaktan sonra yeni OBS kaynağı oluşturulmadı, kaynak ayarları yeniden yazılmadı.
- OBS config.json dosyasında server_enabled:false olsa bile açık bağlantı korundu.
- dB ince ayarı, kulaklıktan bağımsız ses, susturma ve eski yüzde ayarlarının dönüşümü geçti.
- Beş bağlantı testi mevcut bağlantı, canlı sunucu, gerçek kapalı sunucu ve otomatik yeniden bağlanma yollarını doğruladı.

OBS ayar kaynağı: https://github.com/obsproject/obs-websocket/blob/master/src/Config.cpp
