# Contributing

Use Node.js 24+. Run `npm ci` and `npm test`; changes to the audio graph should also pass `npm run test:audio` and `npm run test:browser`.

Keep headphone and broadcast paths independent, preserve selected-tab behavior and retain compatibility with existing local state. Do not commit session keys, OBS passwords, configuration backups or compiled binaries. Report reproducible issues with browser/OBS versions and error text; redact any receiver URL key.

Before changing the bundled helper, test source close/reopen, connection recovery and mute restoration. Explain actual test scope in pull requests; distinguish an OBS simulator from real OBS.

The interface is currently Turkish. Clear labels and small setup steps are preferred.
