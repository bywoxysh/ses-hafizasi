Ses Hafızası — OBS & YouTube Audio

Listen to YouTube quietly in your headphones while sending an independent level to OBS. Capture only the tab you select.

**Windows 10/11 x64 · standard OBS 28+ · Brave/Chromium 116+**

Download and extract the Windows ZIP, run `SesHafizasi.exe`, then load its `uzanti` folder through `brave://extensions` → Developer mode → Load unpacked. In the selected YouTube tab, open the extension and press **Başlat**.

Kulaklığım = headphone volume. Yayın = OBS broadcast gain, in 0.1 dB steps. Existing OBS connections and settings are reused.

7.3.0 gives the extension a searchable public name and adds MIT-licensed source, Turkish/English documentation, tests and a Windows SEA build script. Audio behavior matches reviewed 7.2.1; the bundled helper remains 7.2.0.

Windows ZIP'i çıkar, `SesHafizasi.exe` dosyasını aç, `uzanti` klasörünü Brave'e yükle. İstediğin YouTube sekmesinde uzantıyı açıp **Başlat**'a bas. Kulaklık ve yayın sesini ayrı ayarla. 7.2.1 kullanıyorsan EXE aynı; yalnızca uzantı dosyalarını güncellemen yeterli.

Verification: Chromium tab capture/AudioWorklet, selected-tab isolation, dB/mute settings, source close/reopen and OBS protocol reconnect tests. The OBS backend in automated tests is a simulator; the maintainer reported a successful real Windows Brave/OBS broadcast with the prior helper. See the repository's testing notes for scope.
