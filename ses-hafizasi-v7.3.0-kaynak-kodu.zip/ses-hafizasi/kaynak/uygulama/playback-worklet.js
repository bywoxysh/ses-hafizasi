class PlaybackProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    this.capacity = 32768;
    this.left = new Float32Array(this.capacity);
    this.right = new Float32Array(this.capacity);
    this.read = 0; this.write = 0; this.available = 0; this.phase = 0;
    this.sourceRate = 48000;
    this.started = false;
    this.totalPlayed = 0; this.reportClock = 0; this.reportPeak = 0;
    this.port.onmessage = ({ data }) => {
      if (data?.reset) { this.reset(); return; }
      if (!(data instanceof ArrayBuffer) || data.byteLength < 8) return;
      const view = new DataView(data);
      const rate = view.getUint32(0, true), frames = view.getUint32(4, true);
      if (rate < 8000 || rate > 192000 || frames > 4096 || frames < 1 || data.byteLength !== 8 + frames * 8) return;
      if (this.sourceRate !== rate) { this.reset(); this.sourceRate = rate; }
      // En fazla yaklaşık 250 ms geçmiş ses. Biriken gecikmeyi büyütme.
      if (this.available + frames > Math.min(this.capacity, rate * .25)) this.reset();
      for (let i = 0; i < frames; i++) {
        const left = view.getFloat32(8 + i * 8, true), right = view.getFloat32(12 + i * 8, true);
        this.left[this.write] = Number.isFinite(left) ? left : 0;
        this.right[this.write] = Number.isFinite(right) ? right : 0;
        this.write = (this.write + 1) % this.capacity;
        this.available++;
      }
    };
  }
  reset() {
    this.read = this.write = this.available = this.phase = 0;
    this.started = false;
  }
  process(_inputs, outputs) {
    this.reportClock += outputs[0]?.[0]?.length || 128;
    if (this.reportClock >= sampleRate / 2) {
      this.port.postMessage({ played: this.totalPlayed, peak: this.reportPeak });
      this.reportClock = 0; this.reportPeak = 0;
    }
    const output = outputs[0];
    if (!output?.length) return true;
    for (const channel of output) channel.fill(0);
    const target = Math.ceil(this.sourceRate * .08);
    if (!this.started) {
      if (this.available < target) return true;
      this.started = true;
    }
    // Küçük saat farklılıklarını tampon seviyesine göre telafi et.
    const correction = Math.max(.995, Math.min(1.005, 1 + (this.available - target) / (this.sourceRate * 20)));
    const ratio = this.sourceRate / sampleRate * correction;
    for (let i = 0; i < output[0].length; i++) {
      if (this.available < Math.ceil(ratio) + 1) { this.started = false; this.phase = 0; break; }
      const next = (this.read + 1) % this.capacity;
      output[0][i] = this.left[this.read] * (1 - this.phase) + this.left[next] * this.phase;
      if (output[1]) output[1][i] = this.right[this.read] * (1 - this.phase) + this.right[next] * this.phase;
      this.totalPlayed++;
      this.reportPeak = Math.max(this.reportPeak, Math.abs(output[0][i]), Math.abs(output[1]?.[i] || 0));
      this.phase += ratio;
      const consumed = Math.floor(this.phase);
      this.phase -= consumed;
      this.read = (this.read + consumed) % this.capacity;
      this.available -= consumed;
    }
    return true;
  }
}
registerProcessor('playback-pcm', PlaybackProcessor);
