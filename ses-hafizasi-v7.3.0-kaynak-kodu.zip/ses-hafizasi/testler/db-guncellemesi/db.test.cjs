const test = require('node:test'), assert = require('node:assert/strict'), vm = require('node:vm'), fs = require('node:fs'), path = require('node:path');
const scope = {}; vm.createContext(scope); vm.runInContext(fs.readFileSync(path.join(__dirname,'../../uzanti/router.js'),'utf8')+'\nthis.AudioRouter = AudioRouter; this.migrateLevels = migrateLevels;',scope);
test('Yüzde ayarları korunur; sessiz ayarı gerçekten sessiz kalır',()=>{
 for(const [percent,db] of [[100,0],[10,-20],[5,-26],[1,-40]]) {const s=scope.migrateLevels({listenVolume:1,broadcastVolume:percent});assert.equal(s.broadcastDb,db);assert.equal(s.listenVolume,1);assert.equal(s.broadcastMuted,false);}
 assert.equal(scope.migrateLevels({broadcastVolume:0}).broadcastMuted,true);
 assert.equal(scope.migrateLevels({broadcastDb:-33.7,broadcastMuted:true}).broadcastDb,-33.7);
 for(const value of [NaN,Infinity,-100,5,'-20'])assert.equal(scope.migrateLevels({broadcastDb:value}).broadcastDb,-20);
});
test('dB dönüşümü ve ince ayar yalnızca yayın dalını değiştirir',()=>{
 const router = new scope.AudioRouter(); let value;
 router.context={currentTime:0};router.listen={volume:.01};router.broadcast={gain:{cancelScheduledValues(){},setTargetAtTime(g){value=g;}}};
 router.setBroadcastDb(-20);assert.ok(Math.abs(value-.1)<1e-12);
 router.setBroadcastDb(-26.020599913);assert.ok(Math.abs(value-.05)<1e-10);
 router.setBroadcastDb(-13.9);const fine=value;router.setBroadcastDb(-14);assert.ok(Math.abs(20*Math.log10(fine/value)-.1)<1e-12);
 router.setBroadcastDb(-14,true);assert.equal(value,0);router.setBroadcastDb(-14,false);assert.ok(value>0);assert.equal(router.listen.volume,.01);
 router.setListenVolume(5);assert.equal(router.listen.volume,.05);assert.ok(Math.abs(value-Math.pow(10,-14/20))<1e-12);
 for(const db of [NaN,Infinity,-61,1])assert.throws(()=>router.setBroadcastDb(db));
});
