# Kaynak kodu

Windows programı Node.js 24.21.0 SEA olarak paketlenmiştir. Uygulama kaynakları
uygulama klasöründedir; uzantı ise paketin uzanti klasöründedir. Kaynak kodu
çalıştırmak için Node.js 24 ile `node uygulama/main.cjs` kullanılabilir.

Program Windows'ta standart OBS config.json dosyasını okuyarak sadece yerel
OBS'ye bağlanır. OBS ayar yedeği ve ses ayarlarının geri alma kaydı kullanıcıya
ait LocalAppData/SesHafizasi klasöründe saklanır. Parola HTTP yanıtına veya
uzantıya gönderilmez.

SEA üretirken CommonJS modülleri ve web varlıkları tek JavaScript dosyasında
paketlenmiş, useSnapshot/useCodeCache kapalı tutulmuş ve aynı Node sürümünün
Linux'ta oluşturduğu hazırlık blobu Windows Node yürütücüsüne postject ile
NODE_SEA_BLOB olarak enjekte edilmiştir. Windows dosyasının GUI alt sistemi
seçilmiştir; bu yüzden terminal açılmaz. Node lisansı paketin kökünde mevcuttur.

Resmi belgeler:
https://nodejs.org/docs/latest-v24.x/api/single-executable-applications.html
https://github.com/obsproject/obs-websocket/blob/master/src/Config.cpp
