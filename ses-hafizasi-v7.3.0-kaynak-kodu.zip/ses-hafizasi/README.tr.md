# Ses Hafızası — OBS & YouTube Audio

**YouTube'u kulaklığında kısık dinle, OBS yayınına ayrı bir ses seviyesi gönder.**

Örneğin kulaklığın %1 olabilirken yayın sesini −20 dB ayarlayabilirsin. Yalnızca Başlat'a bastığın sekme yayına gider; diğer sekmeler otomatik eklenmez.

## Kurulum

Depoda yayımlandıktan sonra **Releases** bölümündeki Windows ZIP'ini indir. **Code → Download ZIP** yalnızca kaynak kodudur; hazır EXE içermez.

1. ZIP'i kalıcı bir klasöre çıkar.
2. `brave://extensions` → Geliştirici modu → Paketlenmemiş öğe yükle yoluyla `uzanti` klasörünü seç.
3. `SesHafizasi.exe` dosyasını aç; OBS de açık olsun. Mevcut OBS bağlantısı otomatik kullanılır. Bağlantı etkin değilse uygulama sayfasındaki bir defalık kurulumu tamamla.
4. İstediğin YouTube sekmesinde müziği oynat, o sekmedeyken uzantıya tıkla ve **Başlat**'a bas.
5. **Kulaklığım** yalnızca senin duyduğunu, **Yayın** yalnızca OBS'ye gönderileni ayarlar.

EXE ve uzantı kontrol penceresi açık kalmalı; pencereyi küçültebilirsin. Uygulamanın kurulum web sayfasını kapatabilirsin. Uzantı klasörünü yükledikten sonra taşıma veya silme.

## Günlük kullanım

Yeni sekme seçmek için mevcut kontrol penceresinde **Durdur**, yeni sekmede **Başlat** yap. Seçili sekme kapandığında aktarım ve o kontrol penceresi kapanır. OBS'yi tekrar hazırlamana gerek yoktur.

Yayın kaydırıcısı 0,1 dB adımlıdır; sayı yazıp Enter'a basabilirsin. −25 dB, −26 dB'den daha yüksek ses verir. **Sustur** yayını keser; **Sesi aç** önceki seviyeye döner. Eski %5 yaklaşık −26 dB, %10 −20 dB olur. “Gönderilen ses” satırı gerçek sinyalin tepe seviyesini dBFS olarak gösterir; içerikle değişir.

YouTube'un kendi sesini değiştirmek yerine uzantıyı kullan. Windows'un varsayılan ses çıkışı kulaklığın olsun.

## OBS ve uyumluluk

Windows 10/11 x64, standart OBS Studio 28+ ve Brave/Chromium 116+ hedeflenir. Windows Brave/OBS üzerinde gerçek yayın denemesi başarılı olarak bildirildi. Taşınabilir OBS ve diğer tarayıcılar doğrulanmadı.

Çakışan Masaüstü Sesi/Brave yakalama kaynakları susturulur; mikrofon korunur. Oyun sesini ayrı uygulama yakalama kaynağıyla alman gerekebilir. Uygulamadaki **Eski OBS ses ayarlarını geri al** kaydedilmiş susturma durumlarını geri yükler.

## 7.2.1'den güncelleme

EXE aynı; açık kalabilir. Uzantıda Durdur'a basıp pencereyi kapat. Yeni `uzanti` dosyalarını mevcut uzantı klasörüne kopyala ve Brave uzantılar sayfasında yeniden yükle okuna bas. Yeni görünür ad 7.3.0 sürümündedir; ses sistemi aynı kalır.

## Açık kaynak

[MIT lisansı](LICENSE). Ses yalnızca bilgisayarında işlenir ve aktarılır; hesap, ücret veya sanal ses kablosu gerekmez. Teknik kurulum, test ve derleme için [English README](README.md) ve [BUILD.md](docs/BUILD.md) dosyalarını kullan.
