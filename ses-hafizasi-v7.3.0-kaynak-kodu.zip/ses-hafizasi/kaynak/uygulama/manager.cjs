const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { execFileSync, spawn } = require('node:child_process');
const { ObsClient, planObs, configureObs } = require('./obs.cjs');

class Manager {
  constructor({ dataDir, address, configPath, isObsRunning, launchObs } = {}) {
    this.dataDir = dataDir; this.address = address;
    this.configPath = configPath || process.env.SES_HAFIZASI_OBS_CONFIG ||
      (process.env.APPDATA ? path.join(process.env.APPDATA, 'obs-studio', 'plugin_config', 'obs-websocket', 'config.json') : '');
    this.isObsRunning = isObsRunning || (() => {
      if (process.platform !== 'win32') return false;
      try { return /obs64\.exe/i.test(execFileSync('tasklist.exe', ['/FI', 'IMAGENAME eq obs64.exe', '/NH'], { encoding: 'utf8', windowsHide: true })); }
      catch { throw new Error('OBS’nin açık olup olmadığı kontrol edilemedi.'); }
    });
    this.launchObs = launchObs || (() => {
      const candidates = [process.env.ProgramFiles, process.env['ProgramFiles(x86)']].filter(Boolean)
        .map(base => path.join(base, 'obs-studio', 'bin', '64bit', 'obs64.exe'));
      const executable = candidates.find(file => fs.existsSync(file));
      if (!executable) return false;
      const child = spawn(executable, [], { cwd: path.dirname(executable), detached: true, stdio: 'ignore', windowsHide: false });
      child.on('error', () => {}); child.unref(); return true;
    });
    this.client = new ObsClient(); this.busy = false; this.key = null;
    this.state = { phase: 'waiting', message: 'OBS kontrol ediliyor…', sourceReady: false, conflicts: [], version: '7.2.0' };
    this.client.onClose = () => { this.state.phase = 'reconnecting'; this.state.sourceReady = false; this.state.message = 'OBS kapalı. OBS’yi açınca yeniden bağlanır.'; };
    this.client.onEvent = event => {
      if (event.eventType !== 'InputVolumeMeters' || !this.state.inputName) return;
      const input = event.eventData.inputs.find(item => item.inputName === this.state.inputName);
      const values = (input?.inputLevelsMul || []).flat().filter(Number.isFinite);
      const peak = values.length ? Math.max(...values) : 0;
      this.state.obsPeak = peak;
    };
  }
  readConfig() {
    if (!this.configPath) throw new Error('Standart OBS ayar klasörü bulunamadı. Bu uygulama Windows’taki normal OBS kurulumunu kullanır.');
    if (!fs.existsSync(this.configPath)) return {};
    try { return JSON.parse(fs.readFileSync(this.configPath, 'utf8')); }
    catch { throw new Error('OBS ayar dosyası okunamadı. Mevcut dosya değiştirilmedi.'); }
  }
  async connect() {
    // Çalışan bağlantı ayar dosyasının eski bir kopyası yüzünden kesilmez.
    if (this.client.ready) return true;
    const config = this.readConfig();
    this.state.phase = 'connecting'; this.state.message = 'OBS’ye otomatik bağlanılıyor…';
    try {
      // Diskte kapalı görünse de çalışan OBS sunucusu erişilebilir olabilir.
      await this.client.connect(config.server_port || 4455, config.auth_required === false ? '' : (config.server_password || ''));
    } catch (error) {
      if (config.server_enabled) throw error;
      this.state.phase = 'setup-needed';
      this.state.message = 'OBS bağlantısı etkin değil. İlk kurulumu uygulamadan bir kez tamamla.';
      return false;
    }
    this.state.phase = 'connected'; this.state.message = 'OBS bağlı. YouTube’da uzantıyı açıp Başlat’a bas.';
    return true;
  }
  async inspect() {
    this.plan = await planObs(this.client, this.address);
    const { currentProgramSceneName } = await this.client.request('GetSceneList');
    this.plan.sceneName = currentProgramSceneName; this.plan.sceneExists = true;
    this.state.conflicts = this.plan.conflicts; this.state.scene = currentProgramSceneName;
    this.state.inputName = this.plan.inputName;
    return this.plan;
  }
  async configure() {
    const plan = await this.inspect();
    await configureObs(this.client, this.address, plan, async changed => {
      const file = path.join(this.dataDir, 'mute-backup.json');
      let previous = []; try { previous = JSON.parse(fs.readFileSync(file, 'utf8')); } catch {}
      for (const item of changed) if (!previous.some(old => old.inputName === item.inputName)) previous.push(item);
      fs.writeFileSync(file, JSON.stringify(previous));
    });
    this.state.phase = 'ready'; this.state.sourceReady = true;
    this.state.message = 'Hazır. YouTube’da uzantıyı açıp Başlat’a bas.';
    fs.writeFileSync(path.join(this.dataDir, 'preferences.json'), JSON.stringify({ configured: true }));
  }
  async setup() {
    if (this.busy) throw new Error('OBS bağlantısı hazırlanıyor; birkaç saniye sonra tekrar dene.');
    this.busy = true;
    try {
      if (await this.connect()) { await this.configure(); return; }
      const config = this.readConfig();
      if (!config.server_enabled) {
        if (this.isObsRunning()) { this.state.phase = 'close-obs'; throw new Error('İlk kurulum için OBS’yi bir kez kapat, sonra OBS’yi hazırla düğmesine tekrar bas.'); }
        const backup = path.join(this.dataDir, 'obs-settings-backup.json');
        if (!fs.existsSync(backup)) fs.writeFileSync(backup, JSON.stringify({ path: this.configPath, existed: fs.existsSync(this.configPath), content: fs.existsSync(this.configPath) ? fs.readFileSync(this.configPath, 'utf8') : null }), { mode: 0o600 });
        fs.mkdirSync(path.dirname(this.configPath), { recursive: true });
        const next = { ...config, server_enabled: true, server_port: config.server_port || 4455, server_password: config.server_password || crypto.randomBytes(24).toString('base64url'), auth_required: true, first_load: false };
        const temporary = this.configPath + '.ses-hafizasi.tmp';
        fs.writeFileSync(temporary, JSON.stringify(next, null, 2), { mode: 0o600 }); fs.renameSync(temporary, this.configPath);
        this.state.phase = 'open-obs'; this.state.message = this.launchObs() ? 'Ayarlar hazırlandı. OBS açılıyor; açılınca otomatik tamamlanacak.' : 'Ayarlar hazırlandı. OBS’yi aç; kurulum otomatik tamamlanacak.';
        this.pendingSetup = true; return;
      }
      if (!await this.connect()) return;
      await this.configure();
    } finally { this.busy = false; }
  }
  async ensureStart() {
    for (let attempt = 0; this.busy && attempt < 30; attempt++) await new Promise(resolve => setTimeout(resolve, 150));
    if (this.busy) throw new Error('OBS kurulumu devam ediyor. Birkaç saniye bekle.');
    this.busy = true;
    try {
      if (!await this.connect()) throw new Error('Uygulama penceresinde ilk OBS kurulumunu tamamla.');
      await this.configure();
      return this.snapshot();
    } finally { this.busy = false; }
  }
  async tick() {
    if (this.busy || this.client.ready) return;
    this.busy = true;
    try {
      if (await this.connect()) {
        let configured; try { configured = JSON.parse(fs.readFileSync(path.join(this.dataDir, 'preferences.json'), 'utf8')).configured; } catch {}
        if (this.pendingSetup || configured !== false) { await this.configure(); this.pendingSetup = false; }
        else { await this.inspect(); this.state.phase = 'restored'; this.state.message = 'Ses ayarları geri alınmış. Yeniden kullanmak için YouTube’da Başlat’a bas.'; }
      }
    } catch { if (this.state.phase === 'connecting') { this.state.phase = 'open-obs'; this.state.message = 'OBS’yi aç. Bağlantı otomatik kurulacak.'; } }
    finally { this.busy = false; }
  }
  async restore() {
    if (this.busy) throw new Error('Kurulum devam ediyor. Biraz bekle.');
    const muteFile = path.join(this.dataDir, 'mute-backup.json');
    if (this.client.ready && fs.existsSync(muteFile)) {
      const previous = JSON.parse(fs.readFileSync(muteFile, 'utf8')), failed = [];
      for (const item of previous) try { await this.client.request('SetInputMute', item); } catch { failed.push(item); }
      fs.writeFileSync(muteFile, JSON.stringify(failed));
      if (this.state.inputName) await this.client.request('SetInputMute', { inputName: this.state.inputName, inputMuted: true });
      fs.writeFileSync(path.join(this.dataDir, 'preferences.json'), JSON.stringify({ configured: false }));
      this.state.sourceReady = false; this.state.phase = 'restored';
      this.state.message = failed.length ? 'Bazı kaynak adları değişmiş; ses ayarları tamamen geri alınamadı.' : 'Önceki OBS ses ayarları geri alındı.';
      return;
    }
    throw new Error('Önce OBS’yi aç; eski ses ayarları geri alınacak.');
  }
  snapshot() { return { ...this.state, busy: this.busy, obsConnected: this.client.ready }; }
  start() {
    if (process.platform === 'win32') {
      let configured = false; try { configured = JSON.parse(fs.readFileSync(path.join(this.dataDir, 'preferences.json'), 'utf8')).configured; } catch {}
      if (configured && !this.isObsRunning()) this.launchObs();
    }
    this.timer = setInterval(() => this.tick(), 2500); this.timer.unref(); this.tick();
  }
  close() { clearInterval(this.timer); this.client.close(); }
}
module.exports = { Manager };
