class CaptureProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    this.frames = 1024;
    this.position = 0;
    this.packet = this.createPacket();
  }
  createPacket() {
    const buffer = new ArrayBuffer(8 + this.frames * 8);
    const header = new DataView(buffer);
    header.setUint32(0, sampleRate, true);
    header.setUint32(4, this.frames, true);
    return buffer;
  }
  process(inputs, outputs) {
    // Bu kol yalnızca yayın içindir. Yerel hoparlöre yayın sesini çalma.
    for (const output of outputs) for (const channel of output) channel.fill(0);
    const input = inputs[0];
    if (!input?.length) return true;
    const left = input[0], right = input[1] || left;
    const data = new DataView(this.packet);
    for (let i = 0; i < left.length; i++) {
      data.setFloat32(8 + this.position * 8, left[i], true);
      data.setFloat32(12 + this.position * 8, right[i], true);
      if (++this.position === this.frames) {
        this.port.postMessage(this.packet, [this.packet]);
        this.packet = this.createPacket();
        this.position = 0;
        // İşlem bloğunun paket sınırını aşması durumunda yeni paketi kullan.
        return this.processRemainder(left, right, i + 1);
      }
    }
    return true;
  }
  processRemainder(left, right, start) {
    const data = new DataView(this.packet);
    for (let i = start; i < left.length; i++) {
      data.setFloat32(8 + this.position * 8, left[i], true);
      data.setFloat32(12 + this.position * 8, right[i], true);
      this.position++;
    }
    return true;
  }
}
registerProcessor('capture-pcm', CaptureProcessor);
