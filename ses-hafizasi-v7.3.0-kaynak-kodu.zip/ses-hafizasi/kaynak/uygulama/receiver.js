let context, player, socket, reconnectTimer, statusTimer, latestPlayed = 0;
function show(message, button = false) {
  document.getElementById('warning').style.display = message ? 'block' : 'none';
  document.getElementById('message').textContent = message || '';
  document.getElementById('enable').style.display = button ? 'inline-block' : 'none';
}
function report() {
  if (socket?.readyState === WebSocket.OPEN) socket.send(JSON.stringify({ type: 'receiver-status', obs: true, revision: 6, audioState: context.state, played: latestPlayed }));
}
function connect() {
  const key = new URL(location.href).searchParams.get('key');
  socket = new WebSocket(`ws://${location.host}/listen?key=${key}`); socket.binaryType = 'arraybuffer';
  socket.onopen = () => {
    report();
    if (context.state !== 'running') show('OBS’de kaynağa sağ tık → Etkileşim → Sesi etkinleştir.', true);
  };
  socket.onmessage = event => {
    if (typeof event.data === 'string') {
      try {
        const state = JSON.parse(event.data);
        if (state.type === 'publisher') {
          player.port.postMessage({ reset: true });
          if (state.active && context.state !== 'running') context.resume().then(report).catch(() => show('Sesi etkinleştir.', true));
        }
      } catch {}
      return;
    }
    if (context.state !== 'running') return;
    player.port.postMessage(event.data, [event.data]); show('');
  };
  socket.onerror = () => socket.close();
  socket.onclose = () => { player.port.postMessage({ reset: true }); show('Yerel uygulama bağlantısı kesildi. SesHafizasi.exe açık mı?'); reconnectTimer = setTimeout(connect, 1500); };
}
async function start() {
  // Normal Brave sekmesinde ikinci bir kulaklık çıkışı oluşmasını engeller.
  if (!window.obsstudio) { show('Bu adres bir OBS ses alıcısıdır. Brave’de bu sayfayı kapat. YouTube sekmesinde Ses Hafızası uzantısını açıp Başlat’a bas.'); return; }
  try {
    context = new AudioContext({ sampleRate: 48000, latencyHint: 'interactive' });
    await context.audioWorklet.addModule('/playback-worklet.js');
    player = new AudioWorkletNode(context, 'playback-pcm', { numberOfInputs: 0, numberOfOutputs: 1, outputChannelCount: [2] });
    player.port.onmessage = event => { latestPlayed = event.data.played; report(); };
    player.connect(context.destination);
    context.onstatechange = () => { report(); if (context.state !== 'running') show('OBS’de kaynağa sağ tık → Etkileşim → Sesi etkinleştir.', true); };
    connect(); statusTimer = setInterval(report, 600);
    if (context.state !== 'running') show('OBS’de kaynağa sağ tık → Etkileşim → Sesi etkinleştir.', true);
    context.resume().catch(error => show(error.message, true));
  } catch (error) { show('Ses başlatılamadı: ' + error.message); }
}
document.getElementById('enable').onclick = async () => {
  if (!context) return;
  try { await context.resume(); report(); if (context.state === 'running') show(''); }
  catch (error) { show(error.message, true); }
};
window.addEventListener('pagehide', () => {
  clearTimeout(reconnectTimer); clearInterval(statusTimer);
  if (socket) { socket.onclose = null; socket.close(); }
  context?.close();
});
start();
