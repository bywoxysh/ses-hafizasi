// Eski yüzde ayarlarını koruyarak dB denetimine geçir.
function migrateLevels(saved = {}) {
  saved = saved || {};
  const listenVolume = typeof saved.listenVolume === 'number' && Number.isFinite(saved.listenVolume) && saved.listenVolume >= 0 && saved.listenVolume <= 100 ? saved.listenVolume : 1;
  let broadcastDb = -20, broadcastMuted = false;
  if (typeof saved.broadcastDb === 'number' && Number.isFinite(saved.broadcastDb) && saved.broadcastDb >= -60 && saved.broadcastDb <= 0) {
    broadcastDb = Math.round(saved.broadcastDb * 10) / 10;
    broadcastMuted = saved.broadcastMuted === true;
  } else if (typeof saved.broadcastVolume === 'number' && Number.isFinite(saved.broadcastVolume) && saved.broadcastVolume >= 0 && saved.broadcastVolume <= 100) {
    broadcastMuted = saved.broadcastVolume === 0;
    if (!broadcastMuted) broadcastDb = Math.max(-60, Math.round(20 * Math.log10(saved.broadcastVolume / 100) * 10) / 10);
  }
  return { listenVolume, broadcastDb, broadcastMuted };
}

function publisherAddress(value) {
  const url = new URL(value);
  if (url.origin !== 'http://127.0.0.1:8765' || url.pathname !== '/' ||
      !/^[a-f0-9]{64}$/.test(url.searchParams.get('key') || '')) {
    throw new Error('SesHafizasi.exe uygulamasının bağlantı adresi geçersiz.');
  }
  return `ws://127.0.0.1:8765/publish?key=${url.searchParams.get('key')}`;
}

class AudioRouter {
  constructor() {
    this.stream = null;
    this.context = null;
    this.socket = null;
    this.onDisconnected = () => {};
    this.onReceivers = () => {};
    this.onMeter = () => {};
    this.onTestEnd = () => {};
  }
  level(value) {
    const number = Number(value);
    if (!Number.isFinite(number) || number < 0 || number > 100) throw new Error('Ses seviyesi 0–100 arasında olmalı.');
    return number / 100;
  }
  async connect(address) {
    this.stop();
    const socket = new WebSocket(publisherAddress(address));
    this.socket = socket;
    socket.onmessage = event => {
      try {
        const message = JSON.parse(event.data);
        if (message.type === 'receivers') this.onReceivers(message);
      } catch { /* ikili yayın verisi bu bağlantıya geri gönderilmez */ }
    };
    await new Promise((resolve, reject) => {
      const timer = setTimeout(() => { socket.close(); reject(new Error('Yerel uygulamaya bağlanılamadı. SesHafizasi.exe açık mı?')); }, 4000);
      socket.onopen = () => { clearTimeout(timer); resolve(); };
      socket.onerror = () => { clearTimeout(timer); reject(new Error('Uygulamaya bağlanılamadı. Adresi kontrol et; başka bir sekme zaten yayınlanıyor olabilir.')); };
      socket.onclose = () => { clearTimeout(timer); reject(new Error('Yerel uygulama bağlantıyı reddetti.')); };
    });
    socket.onclose = () => {
      if (this.socket !== socket) return;
      this.stop();
      this.onDisconnected();
    };
  }
  async start(stream, settings) {
    this.stream = stream;
    try {
      if (this.socket?.readyState !== WebSocket.OPEN) throw new Error('Yerel uygulama bağlantısı yok.');
      const context = new AudioContext({ sampleRate: 48000, latencyHint: 'interactive' });
      this.context = context;
      await context.audioWorklet.addModule('capture-worklet.js');
      this.source = context.createMediaStreamSource(stream);
      // Kulaklık sesi yayın AudioContext'inden tamamen ayrı bir oynatıcıda.
      this.listen = document.createElement('audio');
      this.listen.srcObject = stream;
      this.broadcast = context.createGain();
      const levels = migrateLevels(settings);
      this.setListenVolume(levels.listenVolume);
      this.setBroadcastDb(levels.broadcastDb, levels.broadcastMuted, true);
      const capture = new AudioWorkletNode(context, 'capture-pcm', {
        numberOfInputs: 1, numberOfOutputs: 1, outputChannelCount: [2],
        channelCount: 2, channelCountMode: 'explicit'
      });
      this.capture = capture;
      capture.port.onmessage = event => {
        const socket = this.socket;
        // Ağ yavaşlarsa eski ses biriktirmek yerine bu paketi atla.
        if (socket?.readyState === WebSocket.OPEN && socket.bufferedAmount < 65536) {
          socket.send(event.data);
          if (!this.lastMeter || Date.now() - this.lastMeter >= 250) {
            const view = new DataView(event.data);
            let peak = 0;
            for (let offset = 8; offset < view.byteLength; offset += 4) peak = Math.max(peak, Math.abs(view.getFloat32(offset, true)));
            this.lastMeter = Date.now();
            this.onMeter(peak ? 20 * Math.log10(peak) : -Infinity);
          }
        }
      };
      this.source.connect(this.broadcast).connect(capture).connect(context.destination);
      await context.resume();
      if (context.state !== 'running') throw new Error('Brave ses işlemeyi başlatmadı. Başlat düğmesine yeniden bas.');
      await this.listen.play();
    } catch (error) { this.stop(); throw error; }
  }
  setListenVolume(value) {
    const level = this.level(value);
    if (this.listen) this.listen.volume = level;
  }
  setBroadcastDb(value, muted = false, immediate = false) {
    const db = Number(value);
    if (!Number.isFinite(db) || db < -60 || db > 0) throw new Error('Yayın ayarı −60 ile 0 dB arasında olmalı.');
    if (this.broadcast) {
      const gain = this.broadcast.gain, now = this.context.currentTime;
      gain.cancelScheduledValues(now);
      const target = muted ? 0 : Math.pow(10, db / 20);
      // Başlangıçta tam ses üzerinden rampa yapılmaz; seçili seviye ilk örnekte geçerlidir.
      if (immediate) gain.setValueAtTime(target, now);
      else gain.setTargetAtTime(target, now, 0.01);
    }
  }
  testBroadcast() {
    if (!this.context || this.testTone) throw new Error('Önce Başlat düğmesine bas. Yayın testi zaten çalışıyor olabilir.');
    this.source.disconnect(this.broadcast);
    const tone = this.context.createOscillator();
    this.testTone = tone;
    tone.frequency.value = 440;
    tone.connect(this.broadcast);
    tone.onended = () => {
      if (this.testTone !== tone) return;
      tone.disconnect(); this.testTone = null;
      this.source?.connect(this.broadcast);
      this.onTestEnd();
    };
    tone.start();
    tone.stop(this.context.currentTime + 10);
  }
  stop() {
    const socket = this.socket;
    this.socket = null;
    if (socket) { socket.onclose = null; socket.close(); }
    if (this.capture) this.capture.port.onmessage = null;
    if (this.testTone) {
      this.testTone.onended = null;
      try { this.testTone.stop(); } catch {}
      this.testTone.disconnect(); this.testTone = null;
    }
    if (this.listen) { this.listen.pause(); this.listen.srcObject = null; this.listen.remove(); }
    this.source?.disconnect(); this.broadcast?.disconnect(); this.capture?.disconnect();
    this.context?.close().catch(() => {});
    this.stream?.getTracks().forEach(track => track.stop());
    this.stream = this.context = this.source = this.listen = this.broadcast = this.capture = null;
  }
}
