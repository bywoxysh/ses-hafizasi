# Changelog

## 7.3.0

- Public extension name: **Ses Hafızası — OBS & YouTube Audio**.
- MIT license, Turkish/English documentation, reproducible Windows build script and automated checks.
- Same reviewed audio behavior as 7.2.1; bundled helper remains 7.2.0.

## 7.2.1

- Apply initial broadcast gain immediately before connecting the audio graph, including muted startup.
- Preserve smooth gain changes while running.

## 7.2.0

- Reuse an active OBS connection even when disk configuration is stale.
- Connect to a live OBS server before requesting one-time setup.
- Keep unchanged OBS browser-source settings instead of rewriting/reloading them on every Start.
- Close the controller when its selected source tab is closed.

## 7.1.0

- Replace coarse broadcast percentages with 0.1 dB controls, numeric input and mute.
- Migrate saved percentage settings.
