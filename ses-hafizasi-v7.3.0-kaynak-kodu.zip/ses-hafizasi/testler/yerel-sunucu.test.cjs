const test=require('node:test'), assert=require('node:assert/strict'), net=require('node:net');
const {createRelay,validPacket}=require('../kaynak/uygulama/server.cjs');
const key='a'.repeat(64), extension='chrome-extension://'+'a'.repeat(32);
function packet(frames=1024){const b=Buffer.alloc(8+frames*8);b.writeUInt32LE(48000,0);b.writeUInt32LE(frames,4);for(let i=0;i<frames;i++){b.writeFloatLE(.1,8+i*8);b.writeFloatLE(-.1,12+i*8);}return b;}
function masked(data,opcode=2,final=true){const h=Buffer.alloc(data.length<126?6:8);h[0]=(final?128:0)|opcode;let o=2;if(data.length<126)h[1]=128|data.length;else{h[1]=128|126;h.writeUInt16BE(data.length,2);o=4;}const mask=Buffer.from([11,12,13,14]);mask.copy(h,o);const p=Buffer.from(data);for(let i=0;i<p.length;i++)p[i]^=mask[i%4];return Buffer.concat([h,p]);}
function client(port,role,token=key,origin=role==='publish'?extension:`http://127.0.0.1:${port}`){
 return new Promise((resolve,reject)=>{
 const socket=net.connect(port,'127.0.0.1');let pending=Buffer.alloc(0),upgraded=false;const queue=[],waiters=[];
 const timer=setTimeout(()=>{socket.destroy();reject(Error('handshake timeout'));},2000);
 socket.on('error',reject);
 socket.on('connect',()=>socket.write(`GET /${role}?key=${token} HTTP/1.1\r\nHost: 127.0.0.1:${port}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Version: 13\r\nSec-WebSocket-Key: MDEyMzQ1Njc4OWFiY2RlZg==\r\nOrigin: ${origin}\r\n\r\n`));
 function drain(){while(pending.length>=2){let length=pending[1]&127,o=2;if(length===126){if(pending.length<4)return;length=pending.readUInt16BE(2);o=4;}if(pending.length<o+length)return;const msg={opcode:pending[0]&15,data:Buffer.from(pending.subarray(o,o+length))};pending=pending.subarray(o+length);queue.push(msg);for(let i=0;i<waiters.length;i++){const idx=queue.findIndex(m=>m.opcode===waiters[i].opcode);if(idx>=0){const w=waiters.splice(i--,1)[0];clearTimeout(w.timer);w.resolve(queue.splice(idx,1)[0].data);}}}}
 socket.on('data',chunk=>{pending=Buffer.concat([pending,chunk]);if(!upgraded){const end=pending.indexOf('\r\n\r\n');if(end<0)return;const status=Number(pending.toString('ascii',0,end).split(' ')[1]);clearTimeout(timer);if(status!==101){socket.destroy();resolve({status});return;}upgraded=true;pending=pending.subarray(end+4);resolve({status,socket,send:(data,op=2,fin=true)=>socket.write(masked(data,op,fin)),next(opcode=2){const idx=queue.findIndex(m=>m.opcode===opcode);if(idx>=0)return Promise.resolve(queue.splice(idx,1)[0].data);return new Promise((res,rej)=>{const w={opcode,resolve:res,timer:setTimeout(()=>{const i=waiters.indexOf(w);if(i>=0)waiters.splice(i,1);rej(Error('message timeout'));},2000)};waiters.push(w);});}});}drain();});
 });
}
test('loopback relay authenticates and forwards stereo PCM; fragmented messages and ping work',async()=>{
 const relay=createRelay({key,port:0});const port=await relay.listen();
 try{
  const denied=await fetch(`http://127.0.0.1:${port}/`);assert.equal(denied.status,403);
  const page=await fetch(`http://127.0.0.1:${port}/?key=${key}`);assert.equal(page.status,200);assert.match(await page.text(),/receiver.js/);
  const path=await fetch(`http://127.0.0.1:${port}/server.cjs?key=${key}`);assert.equal(path.status,404);
  assert.equal((await client(port,'publish','b'.repeat(64))).status,403);
  assert.equal((await client(port,'publish',key,'https://evil.example')).status,403);
  const listener=await client(port,'listen');assert.equal(listener.status,101);
  const publisher=await client(port,'publish');assert.equal(publisher.status,101);
  assert.equal((await client(port,'publish')).status,403);
  const count=JSON.parse((await publisher.next(1)).toString());assert.equal(count.count,1);
  const audio=packet();publisher.send(audio);assert.deepEqual(await listener.next(),audio);
  publisher.send(Buffer.from('ping'),9);assert.equal((await publisher.next(10)).toString(),'ping');
  publisher.send(audio.subarray(0,5000),2,false);publisher.send(audio.subarray(5000),0,true);assert.deepEqual(await listener.next(),audio);
  const invalid=packet();invalid.writeFloatLE(NaN,8);const closed=new Promise(res=>publisher.socket.once('close',res));publisher.send(invalid);await closed;
  const state1=JSON.parse((await listener.next(1)).toString());assert.equal(state1.type,'publisher');
 }finally{await relay.close();}
});
test('PCM rejects malformed lengths, invalid samples and invalid rates',()=>{
 assert.ok(validPacket(packet()));assert.equal(validPacket(Buffer.alloc(4)),false);
 const b=packet();b.writeUInt32LE(0,0);assert.equal(validPacket(b),false);
 const c=packet();c.writeFloatLE(Infinity,8);assert.equal(validPacket(c),false);
 assert.equal(validPacket(packet().subarray(0,100)),false);
});
