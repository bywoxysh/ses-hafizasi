const $ = id => document.getElementById(id), sourceId = Number(new URL(location.href).searchParams.get('source'));
const router = new AudioRouter(); let sourceTab, address, busy = false, timer, saving; let broadcastMuted = false;
function status(text, error = false) { $('status').textContent = text; $('status').dataset.error = String(error); }
function levels() { return { listenVolume: Number($('listenVolume').value), broadcastDb: Number($('broadcastDb').value), broadcastMuted }; }
function update() { $('start').disabled = busy || !!router.stream || !sourceTab; $('stop').disabled = busy || !router.stream; $('listenValue').textContent = `%${$('listenVolume').value}`; $('broadcastValue').textContent = broadcastMuted ? 'Sessiz' : Number($('broadcastDb').value).toFixed(1).replace('.', ',').replace('-', '−') + ' dB'; $('broadcastMute').textContent = broadcastMuted ? 'Sesi aç' : 'Sustur'; $('broadcastMute').setAttribute('aria-pressed', String(broadcastMuted)); }
async function api(route, method = 'GET') {
  const response = await fetch('http://127.0.0.1:8765' + route, { method, headers: { 'X-Ses-Hafizasi': '7' }, cache: 'no-store', signal: AbortSignal.timeout(12000) });
  const data = await response.json(); if (!response.ok) throw new Error(data.error || 'Eski uygulama açık. SesHafizasi.exe dosyasını aç.'); return data;
}
async function discover() {
  try { const result = await api('/pair'); if (!['7.0.0', '7.2.0'].includes(result.version)) throw new Error('old'); publisherAddress(result.address); address = result.address; }
  catch { throw new Error('SesHafizasi.exe dosyasını aç; eski terminal penceresini kapat.'); }
}
async function restoreSource() { await chrome.runtime.sendMessage({ type: 'restore-source' }).catch(() => {}); }
function run(promise) { promise.catch(error => status(error.message, true)); }
$('openApp').onclick = () => chrome.tabs.create({ url: 'http://127.0.0.1:8765/app' });
$('start').onclick = () => run((async () => {
  busy = true; update(); status('Hazırlanıyor…'); let stream;
  try {
    await discover(); await api('/api/start', 'POST');
    await router.connect(address);
    const consumer = await chrome.tabs.getCurrent();
    const response = await chrome.runtime.sendMessage({ type: 'capture', consumerTabId: consumer.id });
    if (!response?.streamId) throw new Error(response?.error || 'YouTube sekmesinde uzantıyı yeniden aç.');
    stream = await navigator.mediaDevices.getUserMedia({ audio: { mandatory: { chromeMediaSource: 'tab', chromeMediaSourceId: response.streamId } }, video: false });
    await chrome.scripting.executeScript({ target: { tabId: sourceId }, files: ['source-control.js'] });
    await router.start(stream, levels());
    stream.getTracks().forEach(track => track.addEventListener('ended', () => { run(restoreSource()); router.stop(); update(); status('Kaynak sekmenin sesi sona erdi.'); }));
    status('Kulaklık hazır; yayın bağlantısı bekleniyor…');
  } catch (error) { await restoreSource(); router.stop(); stream?.getTracks().forEach(track => track.stop()); throw error; }
  finally { busy = false; update(); }
})());
$('stop').onclick = () => run((async () => { busy = true; update(); try { await restoreSource(); router.stop(); $('meter').textContent = 'Gönderilen ses: —'; status('Durduruldu.'); } finally { busy = false; update(); } })());
function saveLevels() {
  clearTimeout(saving);
  if ($('remember').checked && sourceTab) saving = setTimeout(() => run(chrome.storage.local.set({ ['host:' + new URL(sourceTab.url).hostname]: levels() })), 350);
}
function applyBroadcast() { router.setBroadcastDb(levels().broadcastDb, broadcastMuted); update(); saveLevels(); }
$('listenVolume').oninput = () => { router.setListenVolume(levels().listenVolume); update(); saveLevels(); };
$('broadcastDb').oninput = () => { $('broadcastDbNumber').value = $('broadcastDb').value; applyBroadcast(); };
$('broadcastDbNumber').onchange = () => {
  const input = $('broadcastDbNumber'), value = input.valueAsNumber;
  if (Number.isFinite(value)) $('broadcastDb').value = Math.round(Math.max(-60, Math.min(0, value)) * 10) / 10;
  input.value = $('broadcastDb').value; applyBroadcast();
};
$('broadcastDbNumber').onkeydown = event => { if (event.key === 'Enter') { event.preventDefault(); $('broadcastDbNumber').onchange(); $('broadcastDbNumber').blur(); } };
$('broadcastMute').onclick = () => { broadcastMuted = !broadcastMuted; applyBroadcast(); };
router.onReceivers = value => { $('connection').textContent = value.ready ? 'OBS ses alıcısı hazır.' : 'OBS ses alıcısı bekleniyor.'; if (router.stream && !busy) status(value.ready ? 'Çalışıyor · Kulaklık ve yayın ayrı.' : 'Kulaklık hazır. OBS’de aktif sahneyi kontrol et.'); };
router.onMeter = db => { $('meter').textContent = 'Gönderilen ses: ' + (Number.isFinite(db) ? db.toFixed(1) + ' dBFS' : 'sessiz'); };
router.onDisconnected = () => { run(restoreSource()); update(); status('Uygulama kapandı. SesHafizasi.exe dosyasını yeniden aç.', true); };
chrome.tabs.onRemoved.addListener(id => { if (id === sourceId) { sourceTab = null; router.stop(); clearTimeout(saving); update(); status('YouTube sekmesi kapatıldı. Yeni sekmede uzantı simgesine tıkla.'); window.close(); } });
window.addEventListener('pagehide', () => { clearInterval(timer); clearTimeout(saving); run(restoreSource()); router.stop(); });
run((async () => {
  sourceTab = await chrome.tabs.get(sourceId); $('source').textContent = sourceTab.title || sourceTab.url;
  const key = 'host:' + new URL(sourceTab.url).hostname, saved = await chrome.storage.local.get(key);
  const settings = migrateLevels(saved[key]);
  $('listenVolume').value = settings.listenVolume;
  $('broadcastDb').value = $('broadcastDbNumber').value = settings.broadcastDb;
  broadcastMuted = settings.broadcastMuted;
  update(); await discover(); const info = await api('/api/status'); status(info.sourceReady ? 'Hazır. Başlat’a bas.' : info.message);
})());
