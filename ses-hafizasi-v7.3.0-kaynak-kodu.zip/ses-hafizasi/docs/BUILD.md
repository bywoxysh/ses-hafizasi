# Build the Windows executable

The reviewed helper uses **Node.js 24.21.0 x64** and postject to make a Single Executable Application (SEA). No runtime npm modules are required. Node's bundled third-party notices are supplied in `NODE-LISANS.txt`.

On Windows, install the official Node.js 24.21.0 x64 build, then from the repository root:

```sh
npm ci
npm run build:windows
```

The output is `dist/SesHafizasi.exe`. Distribute it alongside `uzanti`, `LICENSE`, `NODE-LISANS.txt` and the installation README. Do not commit generated executables to the source repository; attach the packaged ZIP to a GitHub Release.

On Linux x64, use the same Node.js version and provide the official matching Windows x64 `node.exe`:

```sh
node scripts/build-windows.cjs --windows-node=/path/to/node-v24.21.0-win-x64.exe
```

The script embeds CommonJS modules and HTML/JS assets, generates a SEA blob without snapshot/code cache, removes the original Node Authenticode certificate and selects the Windows GUI subsystem. The resulting app has no code-signing certificate. It retains the old LocalAppData path and protocol names to preserve existing installs.

The Linux cross-build script was exercised against the same official Windows Node binary used by the reviewed application. Actual Windows native execution was not available in the build environment; the maintainer tested the prior equivalent helper in a real broadcast.

References: [Node.js SEA documentation](https://nodejs.org/docs/latest-v24.x/api/single-executable-applications.html), [postject](https://github.com/nodejs/postject).
