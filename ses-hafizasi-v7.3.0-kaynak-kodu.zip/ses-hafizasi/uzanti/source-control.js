(() => {
  if (window.__sesHafizasi6) return;
  const originals = new Map();
  function lock(media) {
    if (!(media instanceof HTMLMediaElement)) return;
    if (!originals.has(media)) originals.set(media, { volume: media.volume, muted: media.muted });
    if (media.volume !== 1) media.volume = 1;
    if (media.muted) media.muted = false;
  }
  const listener = event => lock(event.target);
  document.querySelectorAll('video,audio').forEach(lock);
  document.addEventListener('volumechange', listener, true);
  const observer = new MutationObserver(records => {
    for (const record of records) for (const node of record.addedNodes) {
      if (!(node instanceof Element)) continue;
      lock(node);
      node.querySelectorAll('video,audio').forEach(lock);
    }
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });
  window.__sesHafizasi6 = {
    stop() {
      document.removeEventListener('volumechange', listener, true);
      observer.disconnect();
      for (const [media, original] of originals) { media.volume = original.volume; media.muted = original.muted; }
      originals.clear(); delete window.__sesHafizasi6;
    }
  };
})();
