const puppeteer=require('puppeteer');
const {WebSocketServer}=require('ws');
const http=require('node:http'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os');
const {spawn}=require('node:child_process');
const password='test-only-password',pause=ms=>new Promise(r=>setTimeout(r,ms));
let stage='starting';function at(s){stage=s;console.log('STAGE',s);}
function wave(){const rate=48000,frames=rate*4,b=Buffer.alloc(44+frames*2);b.write('RIFF');b.writeUInt32LE(36+frames*2,4);b.write('WAVE',8);b.write('fmt ',12);b.writeUInt32LE(16,16);b.writeUInt16LE(1,20);b.writeUInt16LE(1,22);b.writeUInt32LE(rate,24);b.writeUInt32LE(rate*2,28);b.writeUInt16LE(2,32);b.writeUInt16LE(16,34);b.write('data',36);b.writeUInt32LE(frames*2,40);for(let i=0;i<frames;i++)b.writeInt16LE(Math.round(Math.sin(2*Math.PI*440*i/rate)*.3*32767),44+i*2);return b;}
function mockObs(){
 const states=new Map([['Desktop',{inputName:'Desktop',inputKind:'wasapi_output_capture',muted:false}],['Brave',{inputName:'Brave',inputKind:'wasapi_process_output_capture',muted:false,settings:{window:'YouTube:Chrome_WidgetWin_1:brave.exe'}}],['Mic',{inputName:'Mic',inputKind:'wasapi_input_capture',muted:false}]]);
 const scenes=new Map([['Main',[]]]), calls=[];let current='Main';
 const server=new WebSocketServer({port:14455,host:'127.0.0.1'});
 const sha=s=>crypto.createHash('sha256').update(s).digest('base64');
 server.on('connection',socket=>{
  const salt='salt-for-test',challenge='challenge-for-test';socket.send(JSON.stringify({op:0,d:{rpcVersion:1,authentication:{salt,challenge}}}));let identified=false;
  socket.on('message',raw=>{
   const m=JSON.parse(raw);if(m.op===1){if(m.d.authentication!==sha(sha(password+salt)+challenge)){socket.close(4009);return;}identified=true;socket.send(JSON.stringify({op:2,d:{negotiatedRpcVersion:1}}));return;}
   if(!identified){socket.close(4003);return;}if(m.op!==6)return;
   const {requestType:t,requestId:id,requestData:d}=m.d;calls.push({t,d});let result={},status={result:true,code:100};
   try{switch(t){
    case 'GetVersion':result={obsVersion:'mock OBS 32',obsWebSocketVersion:'5.6',rpcVersion:1};break;
    case 'GetInputList':result={inputs:[...states.values()].map(s=>({inputName:s.inputName,inputKind:s.inputKind}))};break;
    case 'GetSpecialInputs':result={desktop1:'Desktop',desktop2:null,mic1:'Mic'};break;
    case 'GetSceneList':result={currentProgramSceneName:current,scenes:[...scenes.keys()].map(sceneName=>({sceneName}))};break;
    case 'GetInputKindList':result={inputKinds:['browser_source','wasapi_process_output_capture']};break;
    case 'CreateScene':assert.ok(!scenes.has(d.sceneName));scenes.set(d.sceneName,[]);break;
    case 'CreateInput':assert.ok(!states.has(d.inputName));states.set(d.inputName,{inputName:d.inputName,inputKind:d.inputKind,muted:false,monitor:'OBS_MONITORING_TYPE_NONE',volume:1,settings:d.inputSettings});scenes.get(d.sceneName).push({sourceName:d.inputName,sceneItemId:1,sceneItemEnabled:d.sceneItemEnabled});result={sceneItemId:1};break;
    case 'CreateSceneItem':scenes.get(d.sceneName).push({sourceName:d.sourceName,sceneItemId:2,sceneItemEnabled:true});break;
    case 'SetSceneItemEnabled':scenes.get(d.sceneName).find(s=>s.sceneItemId===d.sceneItemId).sceneItemEnabled=d.sceneItemEnabled;break;
    case 'GetSceneItemList':result={sceneItems:scenes.get(d.sceneName)};break;
    case 'GetInputSettings':result={inputSettings:states.get(d.inputName).settings||{},inputKind:states.get(d.inputName).inputKind};break;
    case 'SetInputSettings':states.get(d.inputName).settings={...states.get(d.inputName).settings,...d.inputSettings};break;
    case 'GetInputMute':result={inputMuted:states.get(d.inputName).muted};break;
    case 'SetInputMute':states.get(d.inputName).muted=d.inputMuted;break;
    case 'GetInputAudioMonitorType':result={monitorType:states.get(d.inputName).monitor};break;
    case 'SetInputAudioMonitorType':states.get(d.inputName).monitor=d.monitorType;break;
    case 'GetInputVolume':result={inputVolumeMul:states.get(d.inputName).volume};break;
    case 'SetInputVolume':states.get(d.inputName).volume=d.inputVolumeMul;break;
    default:throw Error('Unsupported '+t);
   }}catch(e){status={result:false,code:600,comment:e.message};}
   socket.send(JSON.stringify({op:7,d:{requestType:t,requestId:id,requestStatus:status,responseData:result}}));
  });
 });
 return{server,states,scenes,calls,close:()=>new Promise(r=>{for(const s of server.clients)s.terminate();server.close(r);})};
}
(async()=>{
 const temporary=fs.mkdtempSync(path.join(os.tmpdir(),'ses7-test-'));
 const config=path.join(temporary,'config.json');fs.writeFileSync(config,JSON.stringify({server_enabled:true,server_port:14455,auth_required:true,server_password:password}));
 const obsMock=mockObs();await new Promise(r=>obsMock.server.once('listening',r));
 const tone=wave();const site=http.createServer((req,res)=>{if(req.url==='/tone.wav'){res.setHeader('Content-Type','audio/wav');return res.end(tone);}res.setHeader('Content-Type','text/html');res.end('<!doctype html><title>YouTube ses testi</title><audio id="media" controls loop src="/tone.wav"></audio><button id="play">Oynat</button><script>media.volume=.01;play.onclick=()=>media.play();</script>');});await new Promise(r=>site.listen(8877,'127.0.0.1',r));
 const app=spawn(process.execPath,[path.resolve(__dirname,'../kaynak/uygulama/main.cjs'),'--no-open'],{env:{...process.env,SES_HAFIZASI_DATA_DIR:path.join(temporary,'appdata'),SES_HAFIZASI_OBS_CONFIG:config},stdio:['ignore','pipe','pipe']});
 let logs='';app.stdout.on('data',d=>{logs+=d;});app.stderr.on('data',d=>{logs+=d;});let browser;
 const headers={'X-Ses-Hafizasi':'7'};const info=async()=>{const r=await fetch('http://127.0.0.1:8765/api/status',{headers});return r.json();};
 try{
  for(let i=0;i<100;i++){try{if((await info()).obsConnected)break;}catch{}await pause(100);}
  assert.equal((await info()).obsConnected,true,logs);at('Source Node.js runtime: OBS credentials read automatically');
  browser=await puppeteer.launch({headless:true,pipe:true,enableExtensions:true,ignoreDefaultArgs:['--mute-audio'],args:['--no-sandbox','--autoplay-policy=no-user-gesture-required']});
  const helper=await browser.newPage();await helper.goto('http://127.0.0.1:8765/app');
  await helper.waitForFunction(()=>document.querySelector('#title').textContent==='Hazır');
  const own=[...obsMock.states.values()].find(x=>x.inputKind==='browser_source');assert.ok(own);assert.equal(obsMock.scenes.size,1);assert.ok(obsMock.scenes.get('Main').some(x=>x.sourceName===own.inputName));assert.equal(obsMock.states.get('Desktop').muted,true);assert.equal(obsMock.states.get('Brave').muted,true);assert.equal(obsMock.states.get('Mic').muted,false);at('One-click setup in current scene, no port/password entry, microphone preserved');
  const ordinary=await browser.newPage();await ordinary.goto(own.settings.url);assert.equal(await ordinary.evaluate(()=>!!context),false);await ordinary.close();
  const receiver=await browser.newPage();await receiver.evaluateOnNewDocument(()=>{window.obsstudio={pluginVersion:'test'};});await receiver.goto(own.settings.url);await receiver.waitForFunction(()=>!!player&&context.state==='running');
  await receiver.evaluate(()=>{window.probe=context.createAnalyser();player.connect(probe);window.quiet=context.createGain();quiet.gain.value=0;probe.connect(quiet).connect(context.destination);window.rms=()=>{const a=new Float32Array(probe.fftSize);probe.getFloatTimeDomainData(a);return Math.sqrt(a.reduce((s,x)=>s+x*x,0)/a.length);};});
  const id=await browser.installExtension(path.resolve(__dirname,'../uzanti'));const extension=(await browser.extensions()).get(id);const source=await browser.newPage();await source.goto('http://127.0.0.1:8877');await source.click('#play');await extension.triggerAction(source);const panel=await(await browser.waitForTarget(t=>t.url().includes('/control.html'))).page();await panel.waitForFunction(()=>!document.querySelector('#start').disabled);await panel.evaluate(() => chrome.storage.local.set({'host:127.0.0.1': {listenVolume: 1, broadcastVolume: 5}})); await panel.reload(); await panel.waitForFunction(() => !document.querySelector('#start').disabled); assert.equal(await panel.$eval('#broadcastDb', e => e.value), '-26'); await panel.evaluate(() => {broadcastDb.value='-20';broadcastDb.dispatchEvent(new Event('input'));}); await panel.click('#start');await panel.waitForFunction(()=>!!router.stream);await pause(1200);
  assert.equal(await source.evaluate(()=>media.volume),1);const base=await receiver.evaluate(()=>rms());assert.ok(base>.018&&base<.024,base);at('Source runtime → real Chrome tab capture → actual receiver audio');
  const other=await browser.newPage(); await other.goto('http://127.0.0.1:8877');await other.click('#play');await other.evaluate(()=>media.volume=1);await pause(600);const withOther=await receiver.evaluate(()=>rms());assert.ok(Math.abs(withOther-base)<.002);
  await other.close();at('Second audible tab does not enter broadcast');
  await panel.screenshot({path:path.join(__dirname,'ekran.png')});
  await panel.evaluate(()=>{listenVolume.value='0';listenVolume.dispatchEvent(new Event('input'));});await pause(400);const headphone0=await receiver.evaluate(()=>rms());assert.ok(Math.abs(headphone0-base)<.002);
  await panel.click('#broadcastMute');await pause(400);const silence=await receiver.evaluate(()=>rms());assert.ok(silence<1e-6);
  await panel.click('#broadcastMute'); await panel.focus('#broadcastDbNumber'); await panel.$eval('#broadcastDbNumber', e => {e.value='-14';}); await panel.keyboard.press('Enter'); assert.equal(await panel.$eval('#broadcastDb',e=>e.value),'-14'); await panel.evaluate(()=>{listenVolume.value='5';listenVolume.dispatchEvent(new Event('input'));});await pause(400);const doubled=await receiver.evaluate(()=>rms());assert.ok(doubled/base>1.8&&doubled/base<2.2);
  const coarseDb = 20*Math.log10(doubled/base); assert.ok(Math.abs(coarseDb-6)<.5,coarseDb);
  await panel.evaluate(()=>{broadcastDb.value='-13.9';broadcastDb.dispatchEvent(new Event('input'));}); await pause(500); const fine = await receiver.evaluate(()=>rms()); const fineDb = 20*Math.log10(fine/doubled); assert.ok(Math.abs(fineDb-.1)<.15,fineDb);
  assert.equal(await panel.$eval('#broadcastDbNumber', e => e.value), '-13.9');
  assert.ok(await panel.$eval('#meter', e => e.textContent.includes('dBFS')));
  await pause(400); const saved = await panel.evaluate(async()=> (await chrome.storage.local.get('host:127.0.0.1'))['host:127.0.0.1']); assert.equal(saved.broadcastDb,-13.9); assert.equal(saved.broadcastMuted,false);
  await panel.click('#stop');await panel.waitForFunction(()=>!router.stream);assert.equal(await source.evaluate(()=>media.volume),.01);at('Independent sliders and source restoration passed');
  const creates = obsMock.calls.filter(x=>x.t==='CreateInput').length, rewrites = obsMock.calls.filter(x=>x.t==='SetInputSettings').length;
  const setupBefore = JSON.parse(fs.readFileSync(config,'utf8')); fs.writeFileSync(config,JSON.stringify({...setupBefore,server_enabled:false}));
  let lastPanel=panel,lastSource=source;const reopenRms=[];
  for(let round=0;round<3;round++){
    await lastPanel.click('#start'); await lastPanel.waitForFunction(()=>!!router.stream); await pause(450);
    for(const socket of obsMock.server.clients)socket.terminate();
  await pause(50);for(let i=0;i<100;i++){if((await info()).obsConnected&&(await info()).sourceReady)break;await pause(100);}
  assert.equal((await info()).obsConnected,true);assert.equal((await info()).sourceReady,true);
  await lastPanel.click('#start');await lastPanel.waitForFunction(()=>!!router.stream);await pause(900);const reconnected=await receiver.evaluate(()=>rms());assert.ok(reconnected>.035&&reconnected<.05,reconnected);
  await lastPanel.click('#stop');await lastPanel.waitForFunction(()=>!router.stream);assert.equal(obsMock.calls.filter(x=>x.t==='CreateInput').length,creates);at('OBS websocket reconnect: no duplicate source, audio resumes');
  await lastSource.close(); await pause(350); assert.equal(lastPanel.isClosed(),true);
    lastSource = await browser.newPage(); await lastSource.goto('http://127.0.0.1:8877');await lastSource.click('#play');await extension.triggerAction(lastSource);
    lastPanel=await(await browser.waitForTarget(t=>t.url().includes('/control.html'))).page();
    await lastPanel.waitForFunction(()=>!document.querySelector('#start').disabled); await lastPanel.click('#start'); await lastPanel.waitForFunction(()=>!!router.stream);await pause(850);
    const rmsNow=await receiver.evaluate(()=>rms());assert.ok(rmsNow>.035&&rmsNow<.05,rmsNow);reopenRms.push(rmsNow);
    await lastPanel.click('#stop'); await lastPanel.waitForFunction(()=>!router.stream);
  }
  assert.equal(obsMock.calls.filter(x=>x.t==='CreateInput').length,creates);assert.equal(obsMock.calls.filter(x=>x.t==='SetInputSettings').length,rewrites);assert.equal(JSON.parse(fs.readFileSync(config,'utf8')).server_enabled,false);at('Three source tab closures/reopens: same OBS connection and source, no setup or source reload');
  for(const socket of obsMock.server.clients)socket.terminate();
  await pause(50);for(let i=0;i<100;i++){if((await info()).obsConnected&&(await info()).sourceReady)break;await pause(100);}
  assert.equal((await info()).obsConnected,true);assert.equal((await info()).sourceReady,true);
  await lastPanel.click('#start');await lastPanel.waitForFunction(()=>!!router.stream);await pause(900);const reconnected=await receiver.evaluate(()=>rms());assert.ok(reconnected>.035&&reconnected<.05,reconnected);
  await lastPanel.click('#stop');await lastPanel.waitForFunction(()=>!router.stream);assert.equal(obsMock.calls.filter(x=>x.t==='CreateInput').length,creates);at('OBS websocket reconnect: no duplicate source, audio resumes');
  await lastSource.close();

  const restore=await fetch('http://127.0.0.1:8765/api/restore',{method:'POST',headers});assert.equal(restore.ok,true);assert.equal(obsMock.states.get('Desktop').muted,false);assert.equal(obsMock.states.get('Brave').muted,false);at('Undo passed');
  fs.writeFileSync(path.join(__dirname,'gercek-tarayici-sonucu.json'),JSON.stringify({runtime:'Node.js 24 source runtime (portable verification script)',obs:'protocol simulator',rms:{base,headphone0,broadcast0:silence,broadcastMinus14:doubled,broadcastMinus13_9:fine,measuredDbChange:coarseDb,measuredFineChange:fineDb,reopenRms,withOther,reconnected},checks:['Second playing tab excluded','Actual OBS websocket disconnect/reconnect','Automatic OBS setup on live connection','Three source close/reopen cycles without setup','Existing connection survives stale disabled config','Existing browser source never reloads','One-click source in current scene','Legacy 5 percent migrated to -26 dB','Numeric dB entry','0.1 dB step','Mute and unmute retain gain','New dB settings persisted','Independent real audio','Source restoration','Mute restore']},null,2));
 }finally{if(browser)await browser.close();app.kill('SIGTERM');await obsMock.close();await new Promise(r=>site.close(r));fs.rmSync(temporary,{recursive:true,force:true});}
})().catch(e=>{console.error('FAILED',stage,e);process.exitCode=1;});
