# Ses Hafızası — OBS & YouTube Audio

**Independent headphone and OBS stream volume for YouTube tabs in Brave/Chromium.**

Listen to YouTube quietly in your headphones while sending a separate level to your OBS stream. One selected browser tab is captured; other tabs are not added to the stream.

[Türkçe kurulum ve kullanım](README.tr.md) · [Build from source](docs/BUILD.md) · [Test results](docs/TESTING.md) · [MIT license](LICENSE)

![Headphone and OBS broadcast controls](docs/images/control.png)

## What it does

- Separate headphone volume (%) and broadcast gain (−60 to 0 dB, 0.1 dB steps).
- Numeric dB entry, broadcast mute and per-site saved settings.
- Automatic setup of an OBS Browser Source in the current scene.
- Reuses the OBS connection and source when you close a tab and select another.
- Local audio transfer over loopback; no audio upload, account or virtual audio cable required.

## Windows quick start

Download the Windows ZIP from this repository's **Releases** section once a release is published. GitHub's **Code → Download ZIP** contains source code, not the standalone EXE.

1. Extract the ZIP into a permanent folder.
2. Open `brave://extensions`, enable **Developer mode**, choose **Load unpacked**, and select `uzanti`.
3. Run `SesHafizasi.exe` and open OBS. If the OBS connection is already enabled, setup is automatic. If it is disabled, the helper page explains the one-time setup.
4. Play audio in the YouTube tab you want to broadcast. Click the extension icon in **that tab**, then **Başlat** (Start).
5. Adjust **Kulaklığım** (Headphones) and **Yayın** (Broadcast) independently.

Keep the EXE and the extension control window open; they may run in the background/minimized. The helper web page can be closed. To change the selected tab, stop the current capture, then start the extension in the new tab. Closing the selected tab stops that capture.

### Requirements and behavior

Windows 10/11 x64, standard OBS Studio 28+ installation and Brave/Chromium 116+ are the intended targets. The audio workflow was tested in Chromium; the maintainer reported a successful real Brave/OBS broadcast on Windows. Other Chromium browsers and portable OBS installations are not verified.

The helper mutes conflicting Desktop Audio / Brave application-capture sources to keep unrelated tabs out of the stream, while preserving microphones. If your game uses Desktop Audio, use a separate application-capture source for the game. The helper's restore button can undo its saved mute changes.

YouTube's media volume is held at full source level during capture; use the extension's two controls. Original media settings are restored on stop. The broadcast dB setting is attenuation, not automatic loudness normalization; the displayed dBFS peak changes with content. Buffering adds latency.

## Run and test the source

Requires Node.js 24+; runtime audio and OBS integration use Node's standard library. Developer dependencies are only for tests/builds.

```sh
npm ci
npm start
npm test
npm run test:audio
npm run test:browser
```

Browser tests use local ports 8765, 8877 and 14455 and an OBS protocol simulator. Stop the real helper before running them. See [test scope](docs/TESTING.md).

## Privacy and compatibility

The server binds only to `127.0.0.1:8765`. A per-install key authenticates audio transport. OBS credentials are read from the standard local OBS configuration and are not sent to the extension. There is no telemetry or remote audio service.

Local state remains in `%LOCALAPPDATA%\SesHafizasi`; existing users keep their OBS source and saved state. Extension 7.3.0 retains the reviewed 7.2.1 audio behavior, with a clearer public name; the bundled helper remains 7.2.0.

## Contribute

See [CONTRIBUTING.md](CONTRIBUTING.md). This project is community software and is not affiliated with OBS, Brave or YouTube.

MIT-licensed application source. The standalone executable bundles Node.js and its third-party notices, supplied in [NODE-LISANS.txt](NODE-LISANS.txt).
