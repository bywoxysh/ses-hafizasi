const fs=require('node:fs'),path=require('node:path'),{spawnSync}=require('node:child_process');
const {inject}=require('postject');
(async()=>{
 const root=path.resolve(__dirname,'..'),dist=path.join(root,'dist'),build=path.join(dist,'sea');
 if(process.versions.node!=='24.21.0'||process.arch!=='x64')throw Error('Use Node.js 24.21.0 x64 to reproduce the reviewed SEA build.');
 const option=process.argv.find(a=>a.startsWith('--windows-node='));
 const target=option?path.resolve(option.slice('--windows-node='.length)):process.platform==='win32'?process.execPath:null;
 if(!target)throw Error('On Linux, pass --windows-node=/path/to/official-node-v24.21.0-win-x64.exe (the same Node version).');
 fs.mkdirSync(build,{recursive:true});
 const app=path.join(root,'kaynak','uygulama'),scripts={},assets={};
 for(const name of fs.readdirSync(app).sort()){
  if(name.endsWith('.cjs'))scripts['./'+name]=fs.readFileSync(path.join(app,name),'utf8');
  else if(/\.(html|js)$/.test(name))assets[name]=fs.readFileSync(path.join(app,name),'utf8');
 }
 const bundle=`const nativeRequire=require;\nconst scripts=${JSON.stringify(scripts)};\nconst assets=${JSON.stringify(assets)};\nconst cache={};\nfunction embeddedRequire(id){if(!scripts[id])return nativeRequire(id);if(cache[id])return cache[id].exports;const module={exports:{}};cache[id]=module;new Function('require','module','exports','__filename','__dirname',scripts[id])(embeddedRequire,module,module.exports,id,require('node:path').dirname(process.execPath));return module.exports;}\nembeddedRequire('./main.cjs').startApp(name=>Buffer.from(assets[name])).catch(error=>{console.error(error.message);process.exitCode=1;});\n`;
 const main=path.join(build,'bundled.cjs'),blob=path.join(build,'blob'),config=path.join(build,'sea-config.json');
 fs.writeFileSync(main,bundle);fs.writeFileSync(config,JSON.stringify({main,output:blob,disableExperimentalSEAWarning:true,useCodeCache:false,useSnapshot:false}));
 const made=spawnSync(process.execPath,['--experimental-sea-config',config],{stdio:'inherit'});if(made.status!==0)throw Error('SEA preparation failed.');
 let binary=fs.readFileSync(target);
 if(binary.length<256||binary.toString('ascii',0,2)!=='MZ')throw Error('Target must be the official Windows x64 node.exe.');
 const pe=binary.readUInt32LE(0x3c),optional=pe+24;
 if(optional+152>binary.length||binary.readUInt32LE(pe)!==0x4550||binary.readUInt16LE(pe+4)!==0x8664||binary.readUInt16LE(optional)!==0x20b)throw Error('Expected Windows PE32+ x64 executable.');
 const certEntry=optional+112+4*8,offset=binary.readUInt32LE(certEntry),length=binary.readUInt32LE(certEntry+4);
 binary.writeUInt32LE(0,certEntry);binary.writeUInt32LE(0,certEntry+4);
 if(offset&&offset+length===binary.length)binary=binary.subarray(0,offset);
 binary.writeUInt16LE(2,optional+68); // GUI subsystem: no console window.
 const executable=path.join(dist,'SesHafizasi.exe');fs.writeFileSync(executable,binary);
 await inject(executable,'NODE_SEA_BLOB',fs.readFileSync(blob),{sentinelFuse:'NODE_SEA_FUSE_fce680ab2cc467b6e072b8b5df1996b2'});
 fs.copyFileSync(path.join(root,'NODE-LISANS.txt'),path.join(dist,'NODE-LISANS.txt'));
 console.log('Built '+executable);
})().catch(error=>{console.error(error.message);process.exitCode=1;});
