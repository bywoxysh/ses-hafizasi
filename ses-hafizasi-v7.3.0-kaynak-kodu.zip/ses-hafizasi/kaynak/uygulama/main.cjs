const fs = require('node:fs'), path = require('node:path'), os = require('node:os'), crypto = require('node:crypto');
const { spawn } = require('node:child_process');
const { Manager } = require('./manager.cjs');
const { createRelay } = require('./server.cjs');
function openPanel() {
  if (process.argv.includes('--no-open') || process.platform !== 'win32') return;
  const child = spawn('rundll32.exe', ['url.dll,FileProtocolHandler', 'http://127.0.0.1:8765/app'], { detached: true, stdio: 'ignore', windowsHide: true });
  child.on('error', () => {}); child.unref();
}
async function startApp(assetReader) {
  const dataDir = process.env.SES_HAFIZASI_DATA_DIR || path.join(process.env.LOCALAPPDATA || os.tmpdir(), 'SesHafizasi');
  fs.mkdirSync(dataDir, { recursive: true });
  const keyFile = path.join(dataDir, 'session-key'); let key;
  try { key = fs.readFileSync(keyFile, 'utf8').trim(); } catch {}
  if (!/^[a-f0-9]{64}$/.test(key || '')) { key = crypto.randomBytes(32).toString('hex'); fs.writeFileSync(keyFile, key, { mode: 0o600 }); }
  const manager = new Manager({ dataDir, address: `http://127.0.0.1:8765/?key=${key}` });
  let relay;
  relay = createRelay({ key, assetReader, api: async (method, route) => {
    if (method === 'GET' && route === '/api/status') return manager.snapshot();
    if (method !== 'POST') throw new Error('Geçersiz işlem.');
    if (route === '/api/setup') { await manager.setup(); return manager.snapshot(); }
    if (route === '/api/start') return manager.ensureStart();
    if (route === '/api/restore') { await manager.restore(); return manager.snapshot(); }
    if (route === '/api/quit') { setTimeout(async () => { manager.close(); await relay.close(); process.exit(0); }, 150); return { ok: true }; }
    throw new Error('İşlem bulunamadı.');
  } });
  try { await relay.listen(); }
  catch (error) {
    if (error.code === 'EADDRINUSE') {
      const response = await fetch('http://127.0.0.1:8765/api/status', { headers: { 'X-Ses-Hafizasi': '7' } }).catch(() => null);
      if (response?.ok && /^7\.\d+\.\d+$/.test((await response.json()).version)) { openPanel(); return; }
      if (process.platform === 'win32') {
        spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', "Add-Type -AssemblyName PresentationFramework; [System.Windows.MessageBox]::Show('Eski Ses Hafizasi uygulamasi acik. Eski terminali kapatip yeniden ac.','Ses Hafizasi')"], { stdio: 'ignore', windowsHide: true });
      }
      throw new Error('Eski Ses Hafızası uygulaması açık. Eski terminali kapat.');
    }
    throw error;
  }
  manager.start(); openPanel();
  const quit = () => { manager.close(); relay.close().then(() => process.exit(0)); };
  process.on('SIGINT', quit); process.on('SIGTERM', quit);
  return { relay, manager };
}
if (require.main === module) startApp().catch(error => { console.error(error.message); process.exitCode = 1; });
module.exports = { startApp };
