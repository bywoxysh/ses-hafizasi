const $ = id => document.getElementById(id); let busy = false, stopped = false;
async function api(route, method = 'GET') {
  const response = await fetch(route, { method, headers: { 'X-Ses-Hafizasi': '7' }, cache: 'no-store' });
  const value = await response.json(); if (!response.ok) throw new Error(value.error); return value;
}
function render(state) {
  $('status').textContent = state.message; $('status').dataset.error = 'false';
  $('title').textContent = state.sourceReady ? 'Hazır' : state.phase === 'restored' ? 'Ses ayarları geri alındı' : state.phase === 'setup-needed' || state.phase === 'close-obs' ? 'İlk kurulum' : 'OBS bağlantısı';
  const needsSetup = ['setup-needed', 'close-obs', 'restored'].includes(state.phase);
  $('setup').style.display = needsSetup ? 'inline-block' : 'none'; $('setupHint').style.display = needsSetup ? 'block' : 'none';
  $('setup').disabled = busy || state.busy;
  $('conflicts').textContent = state.conflicts.length ? 'Çakışan kaynaklar: ' + state.conflicts.join(', ') : 'Ek bir çakışan kaynak yok.';
}
async function action(route) {
  busy = true; $('setup').disabled = true;
  try { render(await api(route, 'POST')); } catch (error) { $('status').textContent = error.message; $('status').dataset.error = 'true'; }
  finally { busy = false; $('setup').disabled = false; }
}
$('setup').onclick = () => action('/api/setup');
$('restore').onclick = () => action('/api/restore');
$('quit').onclick = async () => { stopped = true; await api('/api/quit', 'POST'); $('status').textContent = 'Uygulama kapatıldı. Bu sekmeyi kapatabilirsin.'; $('setup').disabled = true; };
async function refresh() { if (busy || stopped) return; try { render(await api('/api/status')); } catch { $('status').textContent = 'Uygulama kapalı. SesHafizasi.exe dosyasını aç.'; } }
refresh(); setInterval(refresh, 2000);
