const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {Manager}=require('../kaynak/uygulama/manager.cjs');
test('OBS açıkken kapalı bağlantı ayarı değiştirilmez; kapalıyken yedeklenir ve korunarak hazırlanır',async()=>{
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'ses-kurulum-')),configPath=path.join(root,'obs','config.json'),dataDir=path.join(root,'data');fs.mkdirSync(path.dirname(configPath));fs.mkdirSync(dataDir);
 const original=JSON.stringify({server_enabled:false,server_port:14455,server_password:'test-password',auth_required:false,customSetting:'keep'});fs.writeFileSync(configPath,original);
 let running=true,launches=0;const manager=new Manager({dataDir,configPath,address:'http://127.0.0.1:8765/?key='+'a'.repeat(64),isObsRunning:()=>running,launchObs:()=>{launches++;return true;}});
 try {
  await assert.rejects(manager.setup(),/OBS’yi bir kez kapat/);assert.equal(fs.readFileSync(configPath,'utf8'),original);assert.equal(fs.existsSync(path.join(dataDir,'obs-settings-backup.json')),false);
  running=false;await manager.setup();const prepared=JSON.parse(fs.readFileSync(configPath,'utf8'));assert.equal(prepared.server_enabled,true);assert.equal(prepared.auth_required,true);assert.equal(prepared.customSetting,'keep');assert.equal(prepared.server_port,14455);assert.equal(prepared.server_password,'test-password');assert.equal(launches,1);
  const backup=JSON.parse(fs.readFileSync(path.join(dataDir,'obs-settings-backup.json'),'utf8'));assert.equal(backup.content,original);assert.equal(backup.existed,true);
  assert.equal(JSON.stringify(manager.snapshot()).includes('test-password'),false);
 } finally {manager.close();fs.rmSync(root,{recursive:true,force:true});}
});
