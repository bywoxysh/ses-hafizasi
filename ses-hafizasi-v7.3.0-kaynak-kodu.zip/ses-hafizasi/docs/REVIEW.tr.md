Paylaşım öncesi gözden geçirme — 8 Ekim 2026

Sonuç: Başlangıç ses ayarında bir kenar durum düzeltildi. İncelenen ve test edilen yollarda kalan bir engel görülmedi. Bu, her Windows/OBS kurulumunun doğrulandığı anlamına gelmez.

7.2'de yayın GainNode'u varsayılan 1 katsayısından seçilen seviyeye 10 ms zaman sabitiyle geçiyordu. Başlangıçta ses varsa kısa bir süre seçilen seviyenin üzerinde aktarılabilirdi. 7.2.1, başlangıç ayarını ses grafiği bağlanmadan setValueAtTime ile uygular. Sonradan yapılan ses değişiklikleri yumuşak geçmeye devam eder. EXE ve OBS ayar kodu değiştirilmedi.

Doğrulananlar:
- Gerçek Chromium OfflineAudioContext ile -20 dB başlangıcı: ilk örnek ve en yüksek örnek 0,1000000015; eski geçiş yöntemi aynı sabit girişte 1 ile başlıyordu.
- Susturulmuş başlangıç: bütün örnekler sıfır.
- Gerçek sekme yakalama → yerel paketlenmiş Linux SEA → gerçek AudioWorklet ses çıkışı.
- Aynı tarayıcıda ikinci sesli sekme açıldığında yayına gelen ses değişmedi.
- Kulaklık sesi sıfırlanırken yayın sesi korundu; yayın susturma ve dB ince ayarı geçti.
- Seçili sekme üç kez kapatılıp yenisinden başlatıldı; yeni OBS kaynağı oluşturulmadı ve mevcut tarayıcı kaynağı yeniden yüklenmedi.
- OBS WebSocket bağlantısı dört kez gerçekten kesilip yeniden kuruldu; ses yeniden başladı ve kaynak çoğalmadı. OBS tarafı protokol simülatörüydü.
- Yerel sunucu yanlış anahtarı, yabancı web kaynağını ve ikinci eşzamanlı yayıncıyı reddetti; stereo PCM, parçalı mesaj ve ping testleri geçti.
- OBS bağlantısı, ilk kurulum, eski ayar dönüşümü testleri geçti.
- ZIP bütünlüğü ve EXE SHA-256 kontrolü geçti. EXE 7.2 paketindekiyle aynı.
- Paket kişiye ait OBS parolası veya oturum anahtarı içermez; testlerdeki örnek parola yalnızca simülatöre aittir. Çalıştırıldığında her kullanıcının oturum anahtarı kendi yerel veri klasöründe oluşturulur.

Sınırlar:
- Buradaki ses testleri Linux Chromium'da yapıldı. Gerçek Windows Brave ve OBS bu ortamda çalıştırılmadı. Kullanıcı 7.2'yi gerçek yayında sorunsuz denediğini bildirdi.
- Windows 10/11 x64 ve standart OBS Studio 28+ kurulumu hedeflenir.
- Kaynak sekme kapanınca aktarım durur; yeni sekmenin seçilmesi için uzantıda Başlat gerekir.
- Başka OBS masaüstü/Brave yakalama kaynakları elle açılırsa diğer sesler ayrıca yayına gidebilir.

Kaynak testlerini çalıştırmak isteyenler: Node.js 24 ile kaynak klasöründe npm install çalıştırın. Ardından paket kökünden node --test testler/baglanti.test.cjs testler/kurulum.test.cjs testler/db-guncellemesi/db.test.cjs testler/yerel-sunucu.test.cjs kullanın. Tarayıcı testleri node testler/ilk-ses.test.cjs ve node testler/tarayici.test.cjs ile çalıştırılabilir; 8765, 8877 ve 14455 portları boş olmalıdır. Bu araçlar normal kullanım için gerekli değildir.
