const fs=require('node:fs'),path=require('node:path'),{spawnSync}=require('node:child_process');
const root=path.resolve(__dirname,'..'),repo='bywoxysh/ses-hafizasi',version='7.3.0';
const asset=path.join(root,'dist',`ses-hafizasi-v${version}-windows-x64.zip`);
function run(command,args,options={}){const result=spawnSync(command,args,{cwd:root,encoding:'utf8',...options});if(result.error)throw result.error;if(result.status!==0)throw Error(result.stderr||result.stdout||`${command} failed`);return(result.stdout||'').trim();}
try{
 if(!fs.existsSync(asset))throw Error('Release ZIP not found: '+asset);
 run('gh',['auth','status']);
 if(run('gh',['api','user','--jq','.login']).toLowerCase()!=='bywoxysh')throw Error('Authenticate GitHub CLI as bywoxysh before publishing.');
 if(run('git',['status','--porcelain']))throw Error('Commit source changes before publishing.');
 const existing=spawnSync('gh',['repo','view',repo,'--json','nameWithOwner'],{cwd:root,encoding:'utf8'});
 if(existing.status===0)throw Error('Repository already exists. Inspect it before publishing; this script will not overwrite an existing repository.');
 run('gh',['repo','create',repo,'--public','--source',root,'--remote','origin','--push','--description','Independent headphone and OBS stream volume for YouTube tabs. Brave/Chromium extension + local Windows app.'],{stdio:'inherit'});
 const topics=['obs-studio','youtube','brave-browser','browser-extension','audio-routing','volume-control','windows','web-audio-api'];
 run('gh',['repo','edit',repo,...topics.flatMap(topic=>['--add-topic',topic])],{stdio:'inherit'});
 run('gh',['release','create','v'+version,asset,'--repo',repo,'--title',`Ses Hafızası ${version} — OBS & YouTube Audio`,'--notes-file',path.join(root,'docs','RELEASE.md')],{stdio:'inherit'});
 console.log('Published https://github.com/'+repo);
}catch(error){console.error(error.message);process.exitCode=1;}
